# Jarvis pour Android

Assistant vocal : dis « Jarvis », pose ta question, Gemini te répond à voix haute. Fonctionne écran verrouillé. Le bouton « Parler » de la notification reste disponible.

## Ce qu'il te faut

Une **clé API Gemini gratuite** : https://aistudio.google.com/apikey

## Utilisation

1. Ouvre l'app, colle ta clé, appuie sur **Démarrer Jarvis**, accepte les permissions.
2. Appuie sur **Autoriser l'arrière-plan (batterie)**.
3. Attends « Jarvis est prêt » (le premier démarrage charge le modèle, quelques secondes).
4. Dis « Jarvis », attends le bip, pose ta question.

## Notes

- Le mot de réveil est détecté localement avec Vosk (modèle anglais, grammaire limitée au mot « jarvis »).
- Le micro est coupé pendant que Jarvis parle.
- Android 14+ : démarre le service app ouverte, après chaque redémarrage du téléphone.
