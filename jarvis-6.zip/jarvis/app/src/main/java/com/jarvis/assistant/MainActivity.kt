package com.jarvis.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var apiKeyField: EditText
    private lateinit var statusText: TextView
    private lateinit var orb: View
    private lateinit var cardBox: LinearLayout
    private lateinit var questionText: TextView
    private lateinit var answerText: TextView
    private lateinit var startStopButton: Button
    private lateinit var talkButton: Button
    private var pulse: ObjectAnimator? = null

    private val density by lazy { resources.displayMetrics.density }
    private fun dp(v: Int): Int = (v * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE)
        val pad = dp(22)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(28), pad, dp(32))
        }

        // --- En-tête ---
        root.addView(TextView(this).apply {
            text = "JARVIS"
            textSize = 30f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            letterSpacing = 0.35f
            setTextColor(TEXT)
            gravity = Gravity.CENTER
        })

        // --- Orbe animé ---
        orb = View(this)
        root.addView(orb, LinearLayout.LayoutParams(dp(150), dp(150)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(36)
            bottomMargin = dp(28)
        })

        statusText = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(TEXT)
        }
        root.addView(statusText)

        // --- Dernier échange ---
        cardBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(CARD, dp(20))
            visibility = View.GONE
        }
        questionText = TextView(this).apply {
            textSize = 15f
            setTextColor(MUTED)
        }
        answerText = TextView(this).apply {
            textSize = 17f
            setTextColor(TEXT)
            setPadding(0, dp(8), 0, 0)
        }
        cardBox.addView(questionText)
        cardBox.addView(answerText)
        root.addView(cardBox, matchWrap().apply { topMargin = dp(24) })

        // --- Boutons principaux ---
        startStopButton = button("Démarrer Jarvis", filled = true) { onStartStop() }
        root.addView(startStopButton, buttonParams(topMargin = dp(28)))
        talkButton = button("Parler maintenant", filled = false) {
            startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_LISTEN))
        }
        root.addView(talkButton, buttonParams())

        // --- Réglages ---
        root.addView(sectionTitle("Réglages"))
        apiKeyField = EditText(this).apply {
            hint = "Clé API Gemini (AIza…)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString(JarvisService.KEY_API, ""))
            setTextColor(TEXT)
            setHintTextColor(MUTED)
            background = rounded(CARD, dp(14))
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(apiKeyField, matchWrap().apply { topMargin = dp(8) })

        root.addView(SwitchCompat(this).apply {
            text = "Conversation continue : j'écoute la suite sans redire « Jarvis »"
            setTextColor(TEXT)
            isChecked = prefs.getBoolean(JarvisService.KEY_FOLLOWUP, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(JarvisService.KEY_FOLLOWUP, checked).apply()
            }
        }, matchWrap().apply { topMargin = dp(16) })

        root.addView(button("Autoriser contacts, appels et SMS", filled = false) { askOptionalPermissions() },
            buttonParams(topMargin = dp(16)))
        root.addView(button("Autoriser l'arrière-plan (batterie)", filled = false) { requestIgnoreBatteryOptimizations() },
            buttonParams())

        // --- Exemples ---
        root.addView(sectionTitle("Ce que tu peux dire"))
        root.addView(TextView(this).apply {
            text = "• « Jarvis » puis :\n" +
                "• ouvre WhatsApp\n" +
                "• appelle Maman\n" +
                "• envoie un SMS à Paul pour dire que j'arrive\n" +
                "• allume la lampe / éteins la lampe\n" +
                "• monte le volume / volume à 50\n" +
                "• mets en pause / chanson suivante\n" +
                "• minuteur de 10 minutes\n" +
                "• rappelle-moi dans 20 minutes de sortir le riz\n" +
                "• quelle heure est-il ? / combien de batterie ?\n" +
                "• et toute autre question : Gemini répond"
            textSize = 15f
            setTextColor(MUTED)
            setLineSpacing(0f, 1.25f)
            setPadding(0, dp(8), 0, 0)
        })

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(scroll)
        render()
    }

    override fun onResume() {
        super.onResume()
        JarvisState.listener = { render() }
        render()
        pulse?.start()
    }

    override fun onPause() {
        JarvisState.listener = null
        pulse?.cancel()
        super.onPause()
    }

    // ---------- Affichage ----------

    private fun render() {
        val phase = JarvisState.phase
        val (label, color) = when (phase) {
            Phase.STOPPED -> "Jarvis est arrêté" to MUTED
            Phase.LOADING -> "Chargement…" to AMBER
            Phase.WAITING -> "J'attends « Jarvis »" to CYAN
            Phase.LISTENING -> "Je t'écoute…" to GREEN
            Phase.THINKING -> "Je réfléchis…" to VIOLET
            Phase.SPEAKING -> "Je parle…" to BLUE
        }
        statusText.text = label
        statusText.setTextColor(color)
        orb.background = orbDrawable(color)

        startPulse(if (phase == Phase.LISTENING) 500L else 1200L, phase != Phase.STOPPED)

        startStopButton.text = if (phase == Phase.STOPPED) "Démarrer Jarvis" else "Arrêter Jarvis"
        talkButton.isEnabled = phase != Phase.STOPPED
        talkButton.alpha = if (phase == Phase.STOPPED) 0.4f else 1f

        val q = JarvisState.lastQuestion
        val a = JarvisState.lastAnswer
        cardBox.visibility = if (q.isBlank() && a.isBlank()) View.GONE else View.VISIBLE
        questionText.text = if (q.isBlank()) "" else "Toi : $q"
        answerText.text = a
        answerText.visibility = if (a.isBlank()) View.GONE else View.VISIBLE
    }

    private fun startPulse(durationMs: Long, active: Boolean) {
        val current = pulse
        if (!active) {
            current?.cancel()
            pulse = null
            orb.scaleX = 1f
            orb.scaleY = 1f
            return
        }
        if (current != null && current.duration == durationMs && current.isRunning) return
        current?.cancel()
        pulse = ObjectAnimator.ofPropertyValuesHolder(
            orb,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.14f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.14f)
        ).apply {
            duration = durationMs
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun orbDrawable(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setGradientType(GradientDrawable.RADIAL_GRADIENT)
        setGradientRadius(dp(78).toFloat())
        setColors(intArrayOf(lighten(color), color, withAlpha(color, 0x55)))
        setStroke(dp(2), withAlpha(color, 0x99))
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun lighten(c: Int): Int = Color.rgb(
        (Color.red(c) + 255) / 2, (Color.green(c) + 255) / 2, (Color.blue(c) + 255) / 2
    )

    private fun withAlpha(c: Int, alpha: Int): Int = Color.argb(alpha, Color.red(c), Color.green(c), Color.blue(c))

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun buttonParams(topMargin: Int = dp(12)) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply {
            this.topMargin = topMargin
        }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text.uppercase()
        textSize = 13f
        letterSpacing = 0.2f
        setTextColor(CYAN)
        setPadding(0, dp(34), 0, 0)
    }

    private fun button(label: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(if (filled) BG else CYAN)
        background = GradientDrawable().apply {
            cornerRadius = dp(27).toFloat()
            if (filled) {
                setColor(CYAN)
            } else {
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), CYAN)
            }
        }
        setOnClickListener { onClick() }
    }

    // ---------- Actions ----------

    private fun onStartStop() {
        if (JarvisState.phase == Phase.STOPPED) {
            start()
        } else {
            startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
        }
    }

    private fun start() {
        val key = apiKeyField.text.toString().trim()
        if (key.isEmpty()) {
            Toast.makeText(this, "Renseigne ta clé Gemini.", Toast.LENGTH_SHORT).show()
            return
        }
        getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE).edit()
            .putString(JarvisService.KEY_API, key)
            .apply()

        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        needed.addAll(OPTIONAL_PERMS)
        val missing = needed.filter { !granted(it) }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_START)
            return
        }
        launchService()
    }

    private fun askOptionalPermissions() {
        val missing = OPTIONAL_PERMS.filter { !granted(it) }
        if (missing.isEmpty()) {
            Toast.makeText(this, "Déjà autorisé.", Toast.LENGTH_SHORT).show()
            return
        }
        ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_OPTIONAL)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != REQ_START) return
        if (granted(Manifest.permission.RECORD_AUDIO)) launchService()
        else Toast.makeText(this, "Le micro est nécessaire.", Toast.LENGTH_LONG).show()
    }

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    /** Le service micro doit être lancé pendant que l'app est visible (règle Android 14+). */
    private fun launchService() {
        ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
        Toast.makeText(this, "Jarvis démarre. Attends « Jarvis est prêt », puis dis « Jarvis ».", Toast.LENGTH_LONG).show()
    }

    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Déjà autorisé.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:$packageName"))
        )
    }

    companion object {
        private const val REQ_START = 42
        private const val REQ_OPTIONAL = 43

        private val OPTIONAL_PERMS = listOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS
        )

        private val BG = Color.parseColor("#0B1220")
        private val CARD = Color.parseColor("#141E33")
        private val TEXT = Color.parseColor("#E6EDF7")
        private val MUTED = Color.parseColor("#8A97AD")
        private val CYAN = Color.parseColor("#22D3EE")
        private val GREEN = Color.parseColor("#34D399")
        private val AMBER = Color.parseColor("#FBBF24")
        private val VIOLET = Color.parseColor("#A78BFA")
        private val BLUE = Color.parseColor("#60A5FA")
    }
}
