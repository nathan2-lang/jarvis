# Jarvis pour Android

Assistant vocal en français : dis « Jarvis », puis parle. Jarvis exécute les commandes du téléphone ou répond avec Gemini, à voix haute. Fonctionne écran verrouillé. Le bouton « Parler » de la notification reste disponible.

## Ce qu'il te faut

Une **clé API Gemini gratuite** : https://aistudio.google.com/apikey

## Utilisation

1. Ouvre l'app, colle ta clé, appuie sur **Démarrer Jarvis**, accepte les permissions (micro, contacts, appels, SMS).
2. Appuie sur **Autoriser l'arrière-plan (batterie)**.
3. Attends « Jarvis est prêt » (le premier démarrage charge le modèle, quelques secondes).
4. Dis « Jarvis », attends le bip, parle.

## Commandes du téléphone (sans internet, sans Gemini)

- « ouvre WhatsApp », « lance YouTube »
- « appelle Maman », « appelle le 0102030405 »
- « envoie un SMS à Paul pour dire que j'arrive » (Jarvis demande confirmation avant d'envoyer)
- « allume la lampe » / « éteins la lampe »
- « monte le volume », « baisse le volume », « volume à 50 », « coupe le son »
- « mets en pause », « reprends la musique », « chanson suivante » (pour l'appli de musique active)
- « minuteur de 10 minutes », « annule le minuteur »
- « rappelle-moi dans 20 minutes de sortir le riz »
- « quelle heure est-il ? », « quel jour on est ? », « combien de batterie ? »
- « répète », « merci » (termine la conversation), « éteins-toi » (arrête Jarvis)

Tout le reste est envoyé à Gemini. Après une réponse, Jarvis écoute la suite sans redire « Jarvis » (désactivable dans les réglages).

## Notes

- Le mot de réveil est détecté localement avec Vosk (modèle anglais, grammaire limitée au mot « jarvis »). Tes phrases sont comprises par la reconnaissance vocale française d'Android.
- Le micro est coupé pendant que Jarvis parle. Toucher « Parler » l'interrompt.
- Android peut refuser d'ouvrir une appli depuis l'arrière-plan : dans ce cas Jarvis affiche une notification « Touche pour ouvrir… ».
- Les minuteurs et rappels vivent dans le service : si tu arrêtes Jarvis, ils sont annulés.
- Android 14+ : démarre le service app ouverte, après chaque redémarrage du téléphone.
- L'APK est signé avec une clé fixe (app/debug.keystore) : les mises à jour s'installent par-dessus l'ancienne version.
