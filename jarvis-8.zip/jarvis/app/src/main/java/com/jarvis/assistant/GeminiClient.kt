package com.jarvis.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Réponse de Gemini. [ok] est faux quand [text] est un message d'erreur. */
class GeminiReply(val text: String, val ok: Boolean)

/** Client minimal pour l'API Gemini (offre gratuite de Google AI Studio). */
class GeminiClient(private val apiKey: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    /** Historique : paires (rôle, texte), rôle = "user" ou "model". */
    private val history = mutableListOf<Pair<String, String>>()

    /** Envoie une phrase et retourne la réponse (appel bloquant : à lancer hors du thread principal). */
    @Synchronized
    fun ask(userText: String): GeminiReply {
        history.add("user" to userText)

        val contents = JSONArray()
        history.forEach { (role, text) ->
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }

        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt())))
            )
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 400))
            .toString()
            .toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body)
            .build()

        return try {
            http.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    history.removeLastOrNull()
                    return GeminiReply(errorMessage(response.code, raw), false)
                }
                val candidates = JSONObject(raw).optJSONArray("candidates")
                val parts = candidates
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                val reply = buildString {
                    if (parts != null) {
                        for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
                    }
                }.trim()

                if (reply.isEmpty()) {
                    history.removeLastOrNull()
                    return GeminiReply("Je ne peux pas répondre à ça.", false)
                }
                history.add("model" to reply)
                trimHistory()
                GeminiReply(reply, true)
            }
        } catch (e: Exception) {
            history.removeLastOrNull()
            GeminiReply("Je n'arrive pas à joindre Gemini. Vérifie ta connexion.", false)
        }
    }

    private fun errorMessage(code: Int, raw: String): String {
        val detail = try {
            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: Exception) {
            ""
        }
        return when {
            code == 429 -> "Limite gratuite atteinte. Réessaie dans une minute."
            code in 400..403 && detail.contains("API key", ignoreCase = true) -> "Ta clé Gemini semble invalide."
            code == 404 -> "Le modèle Gemini $MODEL n'est pas disponible."
            code == 503 -> "Gemini est surchargé. Réessaie dans un instant."
            else -> "Erreur $code de l'API Gemini."
        }
    }

    /** Garde les 10 derniers échanges, en commençant toujours par un message utilisateur. */
    private fun trimHistory() {
        while (history.size > 20) history.removeAt(0)
        while (history.isNotEmpty() && history.first().first != "user") history.removeAt(0)
    }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE d MMMM yyyy 'à' HH:mm", Locale.FRENCH).format(Date())
        return BASE_PROMPT + " Nous sommes le $now (heure du téléphone de l'utilisateur)."
    }

    companion object {
        const val MODEL = "gemini-3.5-flash-lite"

        private const val BASE_PROMPT =
            "Tu es Jarvis, un assistant vocal personnel sur le téléphone Android de l'utilisateur. " +
            "Tu réponds toujours en français. Tes réponses sont lues à voix haute : " +
            "sois bref (une à trois phrases), naturel, sans markdown, sans listes, sans emojis. " +
            "Tu sais déjà ouvrir des applications, appeler un contact, envoyer un SMS, allumer la lampe, " +
            "régler le volume, contrôler la musique, donner l'heure et la batterie, et programmer des " +
            "minuteurs et des rappels : ces commandes sont traitées avant toi, ne dis jamais que tu en es incapable. " +
            "Si la demande est une commande du téléphone que tu n'as pas vue passer, invite l'utilisateur " +
            "à la reformuler simplement, par exemple « ouvre WhatsApp » ou « appelle Maman »."
    }
}
