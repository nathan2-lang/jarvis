package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CompletableDeferred

/**
 * Service d'accessibilité de Jarvis (à activer une fois dans Réglages > Accessibilité > Jarvis).
 *
 * 1. Appuie sur « Envoyer » dans WhatsApp, mais seulement après une commande vocale confirmée,
 *    et vérifie que le bouton a bien disparu (= message parti) avant de le dire à Jarvis.
 * 2. Sert à ouvrir une application même quand une autre (WhatsApp, YouTube…) est au premier plan :
 *    Android 10+ refuse sinon qu'un service en arrière-plan ouvre une appli.
 */
class JarvisAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var waiter: CompletableDeferred<Boolean>? = null
    private var armedUntil = 0L
    private var clickedAt = 0L
    private var clicks = 0

    /** Vérifie régulièrement l'écran WhatsApp tant qu'un envoi est attendu. */
    private val poll = object : Runnable {
        override fun run() {
            tick()
            if (waiter != null) handler.postDelayed(this, POLL_MS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        finish(false)
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        finish(false)
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (waiter != null) tick()
    }

    // ---------- Envoi WhatsApp ----------

    private fun begin(d: CompletableDeferred<Boolean>, timeoutMs: Long) {
        finish(false) // annule un envoi précédent resté en attente
        waiter = d
        armedUntil = SystemClock.elapsedRealtime() + timeoutMs
        clickedAt = 0L
        clicks = 0
        handler.removeCallbacks(poll)
        handler.postDelayed(poll, POLL_MS)
    }

    private fun finish(ok: Boolean) {
        handler.removeCallbacks(poll)
        val w = waiter
        waiter = null
        armedUntil = 0L
        clickedAt = 0L
        clicks = 0
        w?.complete(ok)
    }

    private fun tick() {
        if (waiter == null) return
        val now = SystemClock.elapsedRealtime()
        if (now > armedUntil) {
            finish(false)
            return
        }
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString()
        if (pkg != WA && pkg != WA_BUSINESS) return
        val send = findSend(root)

        if (clickedAt > 0L) {
            // On a cliqué : on attend un instant puis on vérifie que le bouton « Envoyer » a disparu.
            if (now - clickedAt < VERIFY_MS) return
            if (send == null) {
                finish(true)
            } else if (clicks >= MAX_CLICKS) {
                finish(false)
            } else {
                clickedAt = 0L // toujours là : on réessaie au prochain passage
            }
            return
        }
        if (send == null || !send.isEnabled) return
        if (clickNode(send)) {
            clicks++
            clickedAt = now
        }
    }

    /** Clique sur le nœud, ou sur le premier parent cliquable (l'icône seule ne l'est pas toujours). */
    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        return false
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (pkg in listOf(WA, WA_BUSINESS)) {
            val byId = root.findAccessibilityNodeInfosByViewId("$pkg:id/send")
            val hit = byId?.firstOrNull { isSendDescription(it.contentDescription) }
            if (hit != null) return hit
        }
        return findByDescription(root, 0)
    }

    /** Le même bouton devient « Message vocal » quand le champ est vide : on ne le prend pas pour « Envoyer ». */
    private fun isSendDescription(d: CharSequence?): Boolean {
        val s = d?.toString()?.trim()?.lowercase() ?: return true
        return s.isEmpty() || s == "envoyer" || s == "send"
    }

    private fun findByDescription(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 25) return null
        val d = node.contentDescription?.toString()?.trim()?.lowercase()
        if (d == "envoyer" || d == "send") return node
        for (i in 0 until node.childCount) {
            val hit = findByDescription(node.getChild(i), depth + 1)
            if (hit != null) return hit
        }
        return null
    }

    companion object {
        private const val WA = "com.whatsapp"
        private const val WA_BUSINESS = "com.whatsapp.w4b"
        private const val POLL_MS = 400L
        private const val VERIFY_MS = 900L
        private const val MAX_CLICKS = 3

        @Volatile
        private var instance: JarvisAccessibilityService? = null

        /** Vrai si l'utilisateur a activé le service dans les réglages d'accessibilité. */
        fun isRunning(): Boolean = instance != null

        /**
         * À appeler AVANT d'ouvrir WhatsApp. Le résultat vaut vrai seulement quand le bouton
         * « Envoyer » a été pressé ET a disparu ; faux si le délai est dépassé.
         * Renvoie null si le service d'accessibilité n'est pas activé.
         */
        fun beginSend(timeoutMs: Long): CompletableDeferred<Boolean>? {
            val s = instance ?: return null
            val d = CompletableDeferred<Boolean>()
            s.handler.post { s.begin(d, timeoutMs) }
            return d
        }

        fun cancelSend() {
            val s = instance ?: return
            s.handler.post { s.finish(false) }
        }

        /** Ouvre une activité depuis le service d'accessibilité (autorisé en arrière-plan). */
        fun startActivityFromService(intent: Intent): Boolean {
            val s = instance ?: return false
            return try {
                s.startActivity(Intent(intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            } catch (_: Exception) {
                false
            }
        }
    }
}
