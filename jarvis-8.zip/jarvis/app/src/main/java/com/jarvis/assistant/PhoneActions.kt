package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.KeyguardManager
import android.app.SearchManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.PhoneNumberUtils
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Résultat du traitement d'une phrase par les commandes locales. */
sealed class Outcome {
    /**
     * Jarvis dit [text]. Si [shutdown] est vrai, il s'arrête ensuite.
     * Si [endSession] est vrai (« merci », « ok »), il ne réécoute pas et retourne attendre « Jarvis ».
     */
    class Say(val text: String, val shutdown: Boolean = false, val endSession: Boolean = false) : Outcome()

    /** Jarvis pose [prompt]. Si l'utilisateur dit oui, [onYes] est exécuté et son résultat est dit. */
    class Confirm(val prompt: String, val onYes: suspend () -> String) : Outcome()

    /** Ce n'est pas une commande du téléphone : la phrase part vers Gemini. */
    object None : Outcome()
}

/**
 * Commandes du téléphone comprises localement (sans internet, sans Gemini) :
 * heure, date, batterie, lampe, volume, musique, applis, appels, SMS, minuteur, rappels.
 *
 * [schedule] programme une phrase que Jarvis dira dans [delayMs] millisecondes.
 * [cancelTimers] annule tous les minuteurs/rappels et renvoie combien il y en avait.
 */
class PhoneActions(
    private val context: Context,
    private val schedule: (delayMs: Long, spoken: String) -> Unit,
    private val cancelTimers: () -> Int,
    /** Dit une phrase à voix haute sans relancer l'écoute (ex. « Déverrouille ton téléphone »). */
    private val announce: (String) -> Unit = {}
) {

    /** À appeler hors du thread principal (lecture des contacts, etc.). */
    suspend fun handle(raw: String): Outcome {
        val lc = raw.lowercase(Locale.FRENCH).trim()
        val t = norm(raw)
        if (t.isEmpty()) return Outcome.None
        val c = t.removePrefix("jarvis ")
            .removeSuffix(" s il te plait")
            .removeSuffix(" s il vous plait")
            .trim()

        if (c in END_WORDS) {
            return Outcome.Say(if (c.contains("merci")) "Avec plaisir." else "D'accord.", endSession = true)
        }
        if (c in SHUTDOWN_WORDS) return Outcome.Say("À bientôt.", shutdown = true)

        return try {
            whatsappRequest(lc)
                ?: smsRequest(lc)
                ?: reminderRequest(lc)
                ?: timerRequest(c)
                ?: spotifyRequest(c)
                ?: musicRequest(c)
                ?: simpleQuestion(c)
                ?: torchRequest(c)
                ?: volumeRequest(c)
                ?: callRequest(c)
                ?: openAppRequest(c)
                ?: spotifyPlayAnythingRequest(c)
                ?: Outcome.None
        } catch (e: Exception) {
            Outcome.Say("Je n'ai pas réussi à faire ça.")
        }
    }

    // ---------- Heure, date, batterie ----------

    private fun simpleQuestion(c: String): Outcome? {
        if (TIME_RE.matches(c)) {
            val cal = Calendar.getInstance()
            val h = cal.get(Calendar.HOUR_OF_DAY)
            val m = cal.get(Calendar.MINUTE)
            val text = when {
                h == 0 && m == 0 -> "Il est minuit."
                h == 12 && m == 0 -> "Il est midi."
                else -> {
                    val unit = if (h <= 1) "heure" else "heures"
                    "Il est $h $unit" + (if (m == 0) "." else " $m.")
                }
            }
            return Outcome.Say(text)
        }
        if (DATE_RE.matches(c)) {
            val d = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(Date())
            return Outcome.Say("Nous sommes le $d.")
        }
        if (c.contains("batterie") && BATTERY_WORDS.containsMatchIn(c)) return Outcome.Say(battery())
        return null
    }

    private fun battery(): String {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        if (level < 0 || scale <= 0) return "Je n'arrive pas à lire la batterie."
        val pct = level * 100 / scale
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return "Il reste $pct pour cent de batterie" +
            (if (charging) ", et le téléphone est en charge." else ".")
    }

    // ---------- Lampe torche ----------

    private fun torchRequest(c: String): Outcome? {
        if (!TORCH_WORD.containsMatchIn(c)) return null
        val off = TORCH_OFF.containsMatchIn(c)
        val on = TORCH_ON.containsMatchIn(c)
        if (!off && !on) return null
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return Outcome.Say("Je n'ai pas trouvé de lampe sur ce téléphone.")
            cm.setTorchMode(id, !off)
            Outcome.Say(if (off) "Lampe éteinte." else "Lampe allumée.")
        } catch (e: Exception) {
            Outcome.Say("Je n'arrive pas à contrôler la lampe.")
        }
    }

    // ---------- Volume ----------

    private fun volumeRequest(c: String): Outcome? {
        if (!VOLUME_WORD.containsMatchIn(c)) return null
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val step = maxOf(1, max / 5)

        val target: Int = when {
            VOLUME_PCT.containsMatchIn(c) -> {
                val pct = VOLUME_PCT.find(c)!!.groupValues[1].toInt().coerceIn(0, 100)
                (pct * max + 50) / 100
            }
            VOLUME_MAX.containsMatchIn(c) -> max
            VOLUME_MIN.containsMatchIn(c) || c.contains("coupe le son") -> 0
            VOLUME_UP.containsMatchIn(c) -> cur + step
            VOLUME_DOWN.containsMatchIn(c) -> cur - step
            else -> return null
        }
        val v = target.coerceIn(0, max)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, v, AudioManager.FLAG_SHOW_UI)
        return Outcome.Say(if (v == 0) "Son coupé." else "Volume à ${v * 100 / max} pour cent.")
    }

    // ---------- Musique (applis de musique ouvertes : Spotify, YouTube Music, etc.) ----------

    private fun musicRequest(c: String): Outcome? {
        val key = when {
            c in MUSIC_PAUSE -> KeyEvent.KEYCODE_MEDIA_PAUSE
            c in MUSIC_PLAY -> KeyEvent.KEYCODE_MEDIA_PLAY
            c in MUSIC_NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
            c in MUSIC_PREV -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return null
        }
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return Outcome.Say("C'est fait.")
    }

    // ---------- Spotify : « joue Burna Boy sur Spotify » ----------

    private fun spotifyInstalled(): Boolean =
        context.packageManager.getLaunchIntentForPackage(SPOTIFY_PKG) != null

    private suspend fun spotifyRequest(c: String): Outcome? {
        val m = SPOTIFY_RE.find(c) ?: return null
        // « mets en pause sur Spotify » : c'est une pause, pas une recherche.
        if (m.groupValues[1].trim() in setOf("en pause", "pause", "stop")) return null
        return playOnSpotify(m.groupValues[1])
    }

    /** « joue Burna Boy » sans préciser l'appli : on prend Spotify s'il est installé. */
    private suspend fun spotifyPlayAnythingRequest(c: String): Outcome? {
        val m = PLAY_ANY_RE.find(c) ?: return null
        if (!spotifyInstalled()) return null
        return playOnSpotify(m.groupValues[1])
    }

    private fun mediaKey(key: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
    }

    private suspend fun playOnSpotify(rawQuery: String): Outcome {
        val q = rawQuery.trim().replace(Regex("^(?:du|de la|de l|des|de|le|la|les|l|un|une|ma|mon|mes) "), "").trim()
        val spotify = context.packageManager.getLaunchIntentForPackage(SPOTIFY_PKG)
            ?: return Outcome.Say("Spotify n'est pas installé sur ce téléphone.")
        if (q.isEmpty() || q in GENERIC_MUSIC) {
            // Pas de titre précis : on ouvre Spotify, on le laisse démarrer, puis on lance la lecture.
            val l = launchApp(spotify, "Spotify")
            if (l == Launch.FAILED) return Outcome.Say("Je n'arrive pas à ouvrir Spotify.")
            delay(2000)
            mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            return Outcome.Say(withHint("Je lance Spotify.", l))
        }
        val search = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(SPOTIFY_PKG)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(SearchManager.QUERY, q)
        }
        var l = launchApp(search, "Spotify")
        if (l == Launch.FAILED) {
            // Spotify ne gère pas la recherche vocale : on ouvre au moins sa page de recherche.
            val uri = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q))).setPackage(SPOTIFY_PKG)
            l = launchApp(uri, "Spotify")
        }
        if (l == Launch.FAILED) return Outcome.Say("Je n'arrive pas à ouvrir Spotify.")
        return Outcome.Say(withHint("Je mets $q sur Spotify.", l))
    }

    // ---------- WhatsApp : message pré-rempli, puis « Envoyer » automatique ----------

    private fun whatsappRequest(lc: String): Outcome? {
        val m = WA_A_RE.find(lc) ?: WA_B_RE.find(lc) ?: WA_C_RE.find(lc) ?: return null
        val target = m.groupValues[1].trim().replace(Regex("^(?:mon|ma|mes|le|la|l')\\s*"), "")
        val body = m.groupValues[2].trim().trimEnd('.', '!').replaceFirstChar { it.uppercase() }
        if (target.isEmpty() || body.isEmpty()) return null

        val digits = target.replace(" ", "")
        val number: String
        val name: String
        if (digits.matches(Regex("\\d{2,}"))) {
            number = digits
            name = target
        } else {
            if (!has(Manifest.permission.READ_CONTACTS)) {
                return Outcome.Say("Je n'ai pas accès à tes contacts. Ouvre l'application Jarvis pour les autoriser.")
            }
            val contact = findContact(norm(target))
                ?: return Outcome.Say("Je ne trouve personne qui s'appelle $target dans tes contacts.")
            number = contact.number
            name = contact.name
        }
        val waNumber = whatsappNumber(number)
            ?: return Outcome.Say("Je n'arrive pas à lire le numéro de $name pour WhatsApp.")

        val auto = JarvisAccessibilityService.isRunning()
        val prompt = if (auto) {
            "Je dis à $name sur WhatsApp : $body. J'envoie ?"
        } else {
            "Je prépare à $name sur WhatsApp : $body. J'ouvre la discussion ?"
        }
        return Outcome.Confirm(prompt) { openWhatsApp(waNumber, name, body, auto) }
    }

    /** Numéro au format international sans « + » (ce qu'attend wa.me), ou null. */
    private fun whatsappNumber(raw: String): String? {
        val cleaned = raw.replace(Regex("[^+\\d]"), "")
        if (cleaned.isEmpty()) return null
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val iso = (tm?.simCountryIso?.takeIf { it.isNotBlank() }
            ?: tm?.networkCountryIso?.takeIf { it.isNotBlank() }
            ?: Locale.getDefault().country).uppercase(Locale.ROOT)
        val e164 = try {
            PhoneNumberUtils.formatNumberToE164(cleaned, iso)
        } catch (_: Exception) {
            null
        }
        val full = e164 ?: if (cleaned.startsWith("+")) cleaned else null
        return full?.removePrefix("+")?.takeIf { it.length >= 8 }
    }

    private suspend fun openWhatsApp(waNumber: String, name: String, body: String, auto: Boolean): String {
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b")
            .firstOrNull { context.packageManager.getLaunchIntentForPackage(it) != null }
            ?: return "WhatsApp n'est pas installé sur ce téléphone."
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$waNumber?text=${Uri.encode(body)}"))
            .setPackage(pkg)

        // Sans accessibilité : on prépare la discussion, c'est toi qui appuies sur « Envoyer ».
        val waiter: CompletableDeferred<Boolean>? = if (auto) {
            JarvisAccessibilityService.beginSend(if (isLocked()) SEND_WAIT_LOCKED_MS else SEND_WAIT_MS)
        } else null
        val l = launchApp(intent, "la discussion avec $name")
        if (l == Launch.FAILED) {
            JarvisAccessibilityService.cancelSend()
            return "Je n'arrive pas à ouvrir WhatsApp."
        }
        if (waiter == null) {
            return withHint("La discussion avec $name est prête, appuie sur envoyer.", l)
        }

        if (isLocked()) announce("Déverrouille ton téléphone, j'envoie le message juste après.")
        val sent = withTimeoutOrNull(SEND_WAIT_LOCKED_MS + 5000) { waiter.await() } ?: false
        return if (sent) {
            proof("WhatsApp envoyé à $name", body)
            "Message envoyé à $name sur WhatsApp."
        } else {
            JarvisAccessibilityService.cancelSend()
            "Je n'ai pas réussi à appuyer sur envoyer. Le message est prêt dans la discussion avec $name."
        }
    }

    private fun isLocked(): Boolean =
        (context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager)?.isKeyguardLocked == true

    // ---------- Minuteur et rappels ----------

    private fun timerRequest(c: String): Outcome? {
        if (!TIMER_WORD.containsMatchIn(c)) return null
        if (TIMER_CANCEL.containsMatchIn(c)) {
            val n = cancelTimers()
            return Outcome.Say(if (n > 0) "C'est annulé." else "Tu n'as aucun minuteur en cours.")
        }
        val secs = parseDuration(c)
        if (secs == null && !TIMER_VERB.containsMatchIn(c)) return null
        if (secs == null) return Outcome.Say("Dis-moi la durée, par exemple : minuteur de cinq minutes.")
        if (secs <= 0 || secs > 24 * 3600) return Outcome.Say("Je ne peux pas régler un minuteur de cette durée.")
        val d = spokenDuration(secs)
        schedule(secs * 1000L, "Ton minuteur de $d est terminé. Ton minuteur de $d est terminé.")
        return Outcome.Say("C'est parti, minuteur de $d.")
    }

    private fun reminderRequest(lc: String): Outcome? {
        val text = lc.replace("quart d'heure", "quart-heure").replace("quart d heure", "quart-heure")
        val m = REMINDER_A.find(text) ?: REMINDER_B.find(text) ?: return null
        val secs = parseDuration(norm(m.groupValues[1]))
            ?: return Outcome.Say("Je n'ai pas compris dans combien de temps.")
        if (secs <= 0 || secs > 24 * 3600) return Outcome.Say("Je ne peux pas programmer un rappel à cette échéance.")
        val what = secondPerson(m.groupValues[2].trim().trimEnd('.', '!', '?'))
        schedule(secs * 1000L, "Rappel : $what.")
        return Outcome.Say("C'est noté, je te le rappelle dans ${spokenDuration(secs)}.")
    }

    private fun parseDuration(t: String): Int? {
        var total = 0
        var found = false
        for (m in DURATION_RE.findAll(t)) {
            val n = toNumber(m.groupValues[1]) ?: continue
            val unit = m.groupValues[2]
            total += when {
                unit.startsWith("h") -> n * 3600
                unit.startsWith("m") -> n * 60
                else -> n
            }
            found = true
        }
        if (!found) {
            H_FORMAT.find(t)?.let {
                total += it.groupValues[1].toInt() * 3600 + (it.groupValues[2].toIntOrNull() ?: 0) * 60
                found = true
            }
        }
        if (HALF_AFTER_HOUR.containsMatchIn(t)) { total += 1800; found = true }
        else if (QUARTER_AFTER_HOUR.containsMatchIn(t)) { total += 900; found = true }
        else if (t.contains("demi heure") || t.contains("demie heure")) { total += 1800; found = true }
        if (t.contains("quart heure") || t.contains("quart d heure")) { total += 900; found = true }
        return if (found) total else null
    }

    private fun toNumber(s: String): Int? {
        s.toIntOrNull()?.let { return it }
        var sum = 0
        for (w in s.split(" ")) sum += NUM_WORDS[w] ?: return null
        return sum
    }

    private fun spokenDuration(secs: Int): String {
        val h = secs / 3600
        val m = secs % 3600 / 60
        val s = secs % 60
        val parts = mutableListOf<String>()
        if (h > 0) parts.add(if (h == 1) "1 heure" else "$h heures")
        if (m > 0) parts.add(if (m == 1) "1 minute" else "$m minutes")
        if (s > 0) parts.add(if (s == 1) "1 seconde" else "$s secondes")
        return parts.joinToString(" et ")
    }

    /** « sortir mon riz » dit à la deuxième personne : « sortir ton riz ». */
    private fun secondPerson(s: String): String = s
        .replace(Regex("(?<![\\p{L}])j'ai(?![\\p{L}])"), "tu as")
        .replace(Regex("(?<![\\p{L}])je dois(?![\\p{L}])"), "tu dois")
        .replace(Regex("(?<![\\p{L}])me(?![\\p{L}])"), "te")
        .replace(Regex("(?<![\\p{L}])mon(?![\\p{L}])"), "ton")
        .replace(Regex("(?<![\\p{L}])ma(?![\\p{L}])"), "ta")
        .replace(Regex("(?<![\\p{L}])mes(?![\\p{L}])"), "tes")

    // ---------- Ouvrir une application ----------

    private fun openAppRequest(c: String): Outcome? {
        val m = OPEN_RE.find(c) ?: return null
        val verb = m.groupValues[1]
        val query = m.groupValues[2].trim()
        if (query.isEmpty()) return null
        val app = findApp(query)
        if (app == null) {
            return if (verb.startsWith("ouvre") || verb.startsWith("ouvrir")) {
                Outcome.Say("Je ne trouve pas d'application qui s'appelle $query.")
            } else {
                Outcome.None
            }
        }
        return when (launchApp(app.second, app.first)) {
            Launch.OK -> Outcome.Say("J'ouvre ${app.first}.")
            Launch.UNSURE -> Outcome.Say(withHint("J'ouvre ${app.first}.", Launch.UNSURE))
            Launch.FAILED -> Outcome.Say("Je n'arrive pas à ouvrir ${app.first}.")
        }
    }

    private fun findApp(query: String): Pair<String, Intent>? {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0).map {
            val label = it.loadLabel(pm).toString()
            Triple(label, norm(label), it.activityInfo.packageName)
        }
        val candidates = listOfNotNull(query, APP_ALIASES[query])
        for (q in candidates) {
            val hit = apps.firstOrNull { it.second == q }
                ?: apps.firstOrNull { it.second.startsWith(q) }
                ?: apps.firstOrNull { q.length >= 3 && it.second.contains(q) }
                ?: apps.firstOrNull { it.second.length >= 4 && q.contains(it.second) }
            if (hit != null) {
                val intent = pm.getLaunchIntentForPackage(hit.third) ?: continue
                return hit.first to intent
            }
        }
        return null
    }

    private enum class Launch { OK, UNSURE, FAILED }

    private fun withHint(text: String, l: Launch): String =
        if (l == Launch.UNSURE) "$text Si rien ne s'ouvre, touche la notification." else text

    /**
     * Ouvre une appli, même si une autre (WhatsApp…) est au premier plan.
     * Android 10+ bloque l'ouverture depuis l'arrière-plan, sauf pour un service d'accessibilité
     * activé ou une appli autorisée à s'afficher par-dessus les autres.
     *  - OK : lancé par un moyen autorisé.
     *  - UNSURE : essayé, mais Android a peut-être bloqué ; une notification « Touche pour ouvrir » est affichée.
     *  - FAILED : aucune appli ne sait traiter cette demande.
     */
    private fun launchApp(intent: Intent, label: String): Launch {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (JarvisAccessibilityService.startActivityFromService(intent)) return Launch.OK
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            return Launch.FAILED
        }
        if (Settings.canDrawOverlays(context)) return Launch.OK
        postOpenNotification(intent, label)
        return Launch.UNSURE
    }

    private fun postOpenNotification(intent: Intent, label: String) {
        try {
            val nm = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(ACTION_CHANNEL, "Actions de Jarvis", NotificationManager.IMPORTANCE_HIGH)
            channel.setSound(null, null)
            channel.enableVibration(false)
            nm.createNotificationChannel(channel)
            val pi = PendingIntent.getActivity(
                context,
                (System.currentTimeMillis() % 100000).toInt(),
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(context, ACTION_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Jarvis")
                .setContentText("Touche pour ouvrir $label")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .setSilent(true)
                .setTimeoutAfter(15000)
                .build()
            nm.notify(ACTION_NOTIF_ID, n)
        } catch (_: Exception) {
        }
    }

    /** Trace visible d'un message envoyé (les SMS de Jarvis n'apparaissent pas dans l'appli Messages). */
    private fun proof(title: String, text: String) {
        try {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(PROOF_CHANNEL, "Messages envoyés par Jarvis", NotificationManager.IMPORTANCE_LOW)
            )
            val n = NotificationCompat.Builder(context, PROOF_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .build()
            nm.notify(1000 + (System.currentTimeMillis() % 100000).toInt(), n)
        } catch (_: Exception) {
        }
    }

    // ---------- Appels ----------

    @SuppressLint("MissingPermission")
    private fun callRequest(c: String): Outcome? {
        val m = CALL_RE.find(c) ?: return null
        val target = m.groupValues[1].trim().replace(PREFIX_RE, "").trim()
        if (target.isEmpty()) return null

        val digits = target.replace(" ", "")
        val number: String
        val name: String
        if (digits.matches(Regex("\\d{2,}"))) {
            number = digits
            name = target
        } else {
            if (!has(Manifest.permission.READ_CONTACTS)) {
                return Outcome.Say("Je n'ai pas accès à tes contacts. Ouvre l'application Jarvis pour les autoriser.")
            }
            val contact = findContact(target)
                ?: return Outcome.Say("Je ne trouve personne qui s'appelle $target dans tes contacts.")
            number = contact.number
            name = contact.name
        }
        if (!has(Manifest.permission.CALL_PHONE)) {
            return Outcome.Say("Je n'ai pas l'autorisation d'appeler. Ouvre l'application Jarvis pour l'autoriser.")
        }
        val uri = Uri.fromParts("tel", number, null)
        try {
            val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.placeCall(uri, null)
        } catch (e: Exception) {
            launchApp(Intent(Intent.ACTION_DIAL, uri), "le numéro de $name")
        }
        return Outcome.Say("J'appelle $name.")
    }

    // ---------- SMS (toujours avec confirmation) ----------

    private fun smsRequest(lc: String): Outcome? {
        val m = SMS_RE.find(lc) ?: SAY_TO_RE.find(lc)
        if (m == null) {
            return if (SMS_NO_BODY_RE.matches(lc)) {
                Outcome.Say("Dis-moi le message, par exemple : envoie un SMS à Paul pour dire que j'arrive.")
            } else {
                null
            }
        }
        val target = m.groupValues[1].trim().replace(Regex("^(?:mon|ma|mes|le|la|l')\\s*"), "")
        val body = m.groupValues[2].trim().trimEnd('.', '!').replaceFirstChar { it.uppercase() }
        if (target.isEmpty() || body.isEmpty()) return null

        if (!has(Manifest.permission.SEND_SMS)) {
            return Outcome.Say("Je n'ai pas l'autorisation d'envoyer des SMS. Ouvre l'application Jarvis pour l'autoriser.")
        }
        val digits = target.replace(" ", "")
        val number: String
        val name: String
        if (digits.matches(Regex("\\d{2,}"))) {
            number = digits
            name = target
        } else {
            if (!has(Manifest.permission.READ_CONTACTS)) {
                return Outcome.Say("Je n'ai pas accès à tes contacts. Ouvre l'application Jarvis pour les autoriser.")
            }
            val contact = findContact(norm(target))
                ?: return Outcome.Say("Je ne trouve personne qui s'appelle $target dans tes contacts.")
            number = contact.number
            name = contact.name
        }
        return Outcome.Confirm("Je dis à $name : $body. J'envoie ?") { sendSms(number, name, body) }
    }

    /** N'annonce « envoyé » que si l'opérateur a vraiment accepté le SMS. */
    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private suspend fun sendSms(number: String, name: String, body: String): String {
        val action = "com.jarvis.assistant.SMS_SENT_" + System.nanoTime()
        val result = CompletableDeferred<Int>()
        var remaining = 0
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (resultCode != Activity.RESULT_OK) {
                    result.complete(resultCode)
                } else if (--remaining <= 0) {
                    result.complete(Activity.RESULT_OK)
                }
            }
        }
        ContextCompat.registerReceiver(context, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
        return try {
            val sms = if (Build.VERSION.SDK_INT >= 31) {
                context.getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }
            val parts = sms.divideMessage(body)
            remaining = parts.size
            val pi = PendingIntent.getBroadcast(
                context, 0, Intent(action).setPackage(context.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            sms.sendMultipartTextMessage(number, null, parts, ArrayList(parts.map { pi }), null)
            when (withTimeoutOrNull(30_000L) { result.await() }) {
                Activity.RESULT_OK -> {
                    proof("SMS envoyé à $name", body)
                    "Message envoyé à $name."
                }
                SmsManager.RESULT_ERROR_NO_SERVICE -> "Le SMS n'est pas parti : pas de réseau."
                SmsManager.RESULT_ERROR_RADIO_OFF -> "Le SMS n'est pas parti : le mode avion est activé."
                null -> "Je n'ai pas eu de confirmation d'envoi du SMS. Vérifie ta carte SIM."
                else -> "Le SMS n'a pas pu partir."
            }
        } catch (e: Exception) {
            "Je n'ai pas réussi à envoyer le message."
        } finally {
            try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    // ---------- Contacts ----------

    private class ContactMatch(val score: Int, val name: String, val number: String)

    private fun findContact(query: String): ContactMatch? {
        val q = norm(query)
        if (q.isEmpty()) return null
        val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE
        )
        var best: ContactMatch? = null
        context.contentResolver.query(phone, projection, null, null, null)?.use { cur ->
            val iName = cur.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val iNumber = cur.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val iType = cur.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
            while (cur.moveToNext()) {
                val name = cur.getString(iName) ?: continue
                val number = cur.getString(iNumber) ?: continue
                val n = norm(name)
                val base = when {
                    n == q -> 100
                    n.startsWith("$q ") || n.endsWith(" $q") -> 80
                    n.split(" ").contains(q) -> 70
                    n.contains(q) -> 50
                    q.split(" ").all { it.isNotEmpty() && n.contains(it) } -> 40
                    else -> 0
                }
                if (base == 0) continue
                val mobile = cur.getInt(iType) == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                val score = base + if (mobile) 5 else 0
                if (best == null || score > best!!.score) best = ContactMatch(score, name, number)
            }
        }
        return best
    }

    private fun has(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    companion object {
        private const val ACTION_CHANNEL = "jarvis_actions"
        private const val ACTION_NOTIF_ID = 2
        private const val PROOF_CHANNEL = "jarvis_proofs"
        private const val SEND_WAIT_MS = 25_000L
        private const val SEND_WAIT_LOCKED_MS = 60_000L
        private const val SPOTIFY_PKG = "com.spotify.music"

        /** Minuscules, sans accents ni ponctuation : « L'heure, déjà ? » devient « l heure deja ». */
        fun norm(s: String): String =
            Normalizer.normalize(s.lowercase(Locale.FRENCH), Normalizer.Form.NFD)
                .replace(Regex("\\p{Mn}+"), "")
                .replace(Regex("[^a-z0-9 ]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()

        fun isYes(raw: String): Boolean {
            val t = norm(raw)
            if (t.startsWith("non") || t.contains(" pas ") || t.endsWith(" pas")) return false
            return t.startsWith("oui") || t.startsWith("ouais") || t.startsWith("yes") ||
                t in setOf("ok", "d accord", "vas y", "va y", "go", "bien sur", "exactement", "affirmatif") ||
                t.contains("envoie") || t.contains("confirme") || t.contains("c est bon")
        }

        /** Phrases qui terminent la conversation : Jarvis ne réécoute pas et attend « Jarvis ». */
        private val END_WORDS = setOf(
            "merci", "merci beaucoup", "merci jarvis", "ok merci", "d accord merci", "c est bon",
            "c est tout", "ca suffit", "non merci", "non", "laisse tomber", "au revoir",
            "a plus tard", "a plus", "bonne nuit", "stop", "arrete", "tais toi",
            "ok", "okay", "oke", "ok jarvis", "okay jarvis", "d accord", "ok d accord"
        )
        private val SHUTDOWN_WORDS = setOf(
            "eteins toi", "arrete toi", "quitte", "ferme toi", "desactive toi", "coupe toi",
            "arrete jarvis", "eteins jarvis", "jarvis eteins toi"
        )

        private val TIME_RE = Regex(
            "^(?:(?:dis|donne) moi )?(?:il est )?(?:quelle heure(?: est il| il est)?|l heure(?: qu il est| actuelle)?)$"
        )
        private val DATE_RE = Regex(
            "^(?:(?:dis|donne) moi )?(?:quel jour (?:on est|sommes nous|est on|est il)|on est quel jour|" +
                "quelle est la date|quelle date (?:on est|sommes nous)|la date|le jour)(?: aujourd hui)?$"
        )
        private val BATTERY_WORDS = Regex("\\b(combien|quel|quelle|niveau|reste|charge|pourcent)\\b")

        private val TORCH_WORD = Regex("\\b(lampe torche|lampe de poche|torche|lampe|flash)\\b")
        private val TORCH_OFF = Regex("\\b(eteins|eteint|coupe|desactive|arrete|ferme)\\b")
        private val TORCH_ON = Regex("\\b(allume|active|mets|met)\\b")

        private val VOLUME_WORD = Regex("\\b(volume|son)\\b")
        private val VOLUME_PCT = Regex("\\b(?:volume|son) (?:a|au|sur) (\\d{1,3})\\b")
        private val VOLUME_MAX = Regex("\\b(max|maximum|fond)\\b")
        private val VOLUME_MIN = Regex("\\b(min|minimum|zero|muet)\\b")
        private val VOLUME_UP = Regex("\\b(monte|augmente|remonte|hausse|plus fort|plus haut)\\b")
        private val VOLUME_DOWN = Regex("\\b(baisse|diminue|reduis|abaisse|moins fort|plus bas)\\b")

        private val MUSIC_PAUSE = setOf(
            "pause", "mets en pause", "met en pause", "mets pause", "mets la musique en pause",
            "arrete la musique", "coupe la musique", "stoppe la musique", "stop la musique", "arrete la lecture",
            "pause spotify", "mets spotify en pause", "met spotify en pause", "arrete spotify",
            "coupe spotify", "stop spotify", "stoppe spotify", "arrete la chanson", "coupe la chanson",
            "arrete le morceau", "coupe le morceau", "coupe le son de la musique", "ferme la musique"
        )
        private val MUSIC_PLAY = setOf(
            "play", "lecture", "reprends", "mets de la musique", "mets la musique", "lance la musique",
            "lance de la musique", "joue de la musique", "joue la musique", "reprends la musique",
            "reprends la lecture", "relance la musique", "remets la musique",
            "reprends spotify", "relance spotify", "remets spotify", "play spotify"
        )
        private val MUSIC_NEXT = setOf(
            "suivant", "suivante", "next", "chanson suivante", "morceau suivant", "titre suivant",
            "musique suivante", "passe la chanson", "passe cette chanson", "passe au suivant",
            "passe a la suivante", "chanson d apres"
        )
        private val MUSIC_PREV = setOf(
            "precedent", "precedente", "previous", "chanson precedente", "morceau precedent",
            "titre precedent", "musique precedente", "reviens en arriere", "chanson d avant"
        )

        private val SPOTIFY_RE = Regex(
            "^(?:joue|jouer|mets|met|lance|lancer|ecoute|ecouter)(?: moi)? (.+?) (?:sur|avec|dans|depuis) spotify$"
        )
        private val PLAY_ANY_RE = Regex("^(?:joue|jouer)(?: moi)? (.+)$")
        private val GENERIC_MUSIC = setOf(
            "musique", "de la musique", "la musique", "une chanson", "un morceau", "une musique",
            "quelque chose", "un truc", "ma musique", "mes musiques", "mes playlists", "ma playlist"
        )

        private val TIMER_WORD = Regex("\\b(minuteur|minuterie|chrono|compte a rebours|timer)\\b")
        private val TIMER_CANCEL = Regex("\\b(annule|arrete|supprime|stop|eteins|desactive)\\b")
        private val TIMER_VERB = Regex("\\b(mets|met|lance|regle|programme|demarre|fais|active|cree)\\b")

        private val REMINDER_A = Regex(
            """rappelle[- ]moi\s+(?:dans|d'ici)\s+(.+?)\s+(?:de|d'|que|qu'|pour)\s*(.+)"""
        )
        private val REMINDER_B = Regex(
            """(?:dans|d'ici)\s+(.+?)\s+rappelle[- ]moi\s+(?:de|d'|que|qu'|pour)\s*(.+)"""
        )

        private val NUM_WORDS = mapOf(
            "un" to 1, "une" to 1, "deux" to 2, "trois" to 3, "quatre" to 4, "cinq" to 5,
            "six" to 6, "sept" to 7, "huit" to 8, "neuf" to 9, "dix" to 10, "onze" to 11,
            "douze" to 12, "quinze" to 15, "vingt" to 20, "trente" to 30, "quarante" to 40,
            "cinquante" to 50, "soixante" to 60
        )
        private val NUM_ALT = NUM_WORDS.keys.joinToString("|")
        private val DURATION_RE = Regex("(\\d+|(?:$NUM_ALT)(?: (?:$NUM_ALT))?) (heures?|minutes?|min|secondes?|sec)\\b")
        private val H_FORMAT = Regex("\\b(\\d{1,2}) ?h ?(\\d{1,2})?\\b")
        private val HALF_AFTER_HOUR = Regex("heures? et demie?\\b")
        private val QUARTER_AFTER_HOUR = Regex("heures? et quart\\b")

        private val OPEN_RE = Regex(
            "^(ouvre|ouvrir|lance|lancer|demarre|demarrer|va sur|active)(?: moi)? " +
                "(?:l application |l appli |l app |application |appli |app |l |la |le |les |mon |ma )?(.+)$"
        )
        private val APP_ALIASES = mapOf(
            "camera" to "appareil photo", "photo" to "appareil photo",
            "reglages" to "parametres", "parametre" to "parametres", "settings" to "parametres",
            "sms" to "messages", "texto" to "messages", "textos" to "messages",
            "appels" to "telephone", "alarme" to "horloge", "reveil" to "horloge",
            "calendrier" to "agenda", "navigateur" to "chrome", "internet" to "chrome",
            "mail" to "gmail", "email" to "gmail", "carte" to "maps", "cartes" to "maps",
            "store" to "play store"
        )

        private val CALL_RE = Regex("^(?:appelle|appeler|telephone a|passe un coup de fil a|passe un appel a)(?: moi)? (.+)$")
        private val PREFIX_RE = Regex("^(mon|ma|mes|le|la|l|chez) ")

        // Corps du message : « pour dire que… », « en disant que… », « que… »
        private const val BODY_PART =
            """(?:pour\s+(?:lui\s+)?dire(?:\s+que|\s+qu')?|en\s+disant(?:\s+que|\s+qu')?|disant(?:\s+que|\s+qu')?|qui\s+dit(?:\s+que|\s+qu')?|que|qu')\s*(.+)$"""
        private const val WA_VERB = """^(?:envoie|envoi|envoyer|écris|ecris|écrire)(?:-moi)?\s+"""
        // « envoie un WhatsApp à Paul pour dire que… », « envoie un message WhatsApp à Paul que… »
        private val WA_A_RE = Regex(
            WA_VERB + """(?:un\s+|une\s+)?(?:(?:message|msg|mess)\s+)?(?:whatsapp|whats\s+app|watsap)\s+(?:à|a|au)\s+(.+?)\s+""" + BODY_PART
        )
        // « envoie un message à Paul sur WhatsApp pour dire que… »
        private val WA_B_RE = Regex(
            WA_VERB + """(?:un\s+|une\s+)?(?:message|msg|mess)\s+(?:à|a|au)\s+(.+?)\s+(?:sur|par|via)\s+(?:whatsapp|whats\s+app|watsap)\s+""" + BODY_PART
        )
        // « dis à Paul sur WhatsApp que… »
        private val WA_C_RE = Regex(
            """^(?:dis|dites|écris|ecris)\s+(?:à|a)\s+(.+?)\s+(?:sur|par|via)\s+(?:whatsapp|whats\s+app|watsap)\s+(?:que|qu')\s*(.+)$"""
        )

        private val SMS_RE = Regex(
            """^(?:envoie|envoi|envoyer|écris|ecris|écrire)(?:-moi)?\s+(?:un\s+|une\s+)?(?:sms|message|texto|mess)\s+(?:à|a|au)\s+(.+?)\s+""" +
                """(?:pour\s+(?:lui\s+)?dire(?:\s+que|\s+qu')?|en\s+disant(?:\s+que|\s+qu')?|disant(?:\s+que|\s+qu')?|qui\s+dit(?:\s+que|\s+qu')?|que|qu')\s*(.+)$"""
        )
        private val SAY_TO_RE = Regex("""^(?:dis|dites|écris|ecris)\s+(?:à|a)\s+(.+?)\s+(?:que|qu')\s*(.+)$""")
        private val SMS_NO_BODY_RE = Regex(
            """^(?:envoie|envoi|envoyer|écris|ecris|écrire)(?:-moi)?\s+(?:un\s+|une\s+)?(?:sms|message|texto|mess)\s+(?:à|a|au)\s+(.+)$"""
        )
    }
}
