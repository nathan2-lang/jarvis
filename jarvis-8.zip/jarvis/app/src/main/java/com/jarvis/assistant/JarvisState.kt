package com.jarvis.assistant

import android.os.Handler
import android.os.Looper

/** Ce que fait Jarvis en ce moment (affiché dans l'écran principal). */
enum class Phase { STOPPED, LOADING, WAITING, LISTENING, THINKING, SPEAKING }

/** État partagé entre le service (qui écoute et parle) et l'écran. */
object JarvisState {
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var phase: Phase = Phase.STOPPED
        private set

    @Volatile
    var lastQuestion: String = ""
        private set

    @Volatile
    var lastAnswer: String = ""
        private set

    /** Appelé sur le thread principal à chaque changement. */
    @Volatile
    var listener: (() -> Unit)? = null

    fun setPhase(p: Phase) {
        phase = p
        notifyChanged()
    }

    fun update(question: String? = null, answer: String? = null) {
        if (question != null) lastQuestion = question
        if (answer != null) lastAnswer = answer
        notifyChanged()
    }

    private fun notifyChanged() {
        main.post { listener?.invoke() }
    }
}
