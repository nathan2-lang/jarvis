# Jarvis pour Android

Assistant vocal en français : dis « Jarvis », puis parle. Jarvis exécute les commandes du téléphone ou répond avec Gemini, à voix haute. Fonctionne écran verrouillé. Le bouton « Parler » de la notification reste disponible.

## Ce qu'il te faut

Une **clé API Gemini gratuite** : https://aistudio.google.com/apikey

## Utilisation

1. Ouvre l'app, colle ta clé, appuie sur **Démarrer Jarvis**, accepte les permissions (micro, contacts, appels, SMS).
2. Appuie sur **Autoriser l'arrière-plan (batterie)**.
3. Attends « Jarvis est prêt » (le premier démarrage charge le modèle, quelques secondes).
4. Dis « Jarvis », attends le bip, parle.

## Commandes du téléphone (sans internet, sans Gemini)

- « ouvre WhatsApp », « lance YouTube »
- « appelle Maman », « appelle le 0102030405 »
- « envoie un SMS à Paul pour dire que j'arrive » (Jarvis demande confirmation avant d'envoyer)
- « envoie un WhatsApp à Paul pour dire que j'arrive » (confirmation, puis la discussion s'ouvre avec le message ; voir plus bas pour l'envoi automatique)
- « joue Burna Boy sur Spotify », « mets de la musique sur Spotify », « coupe la musique » / « mets Spotify en pause »
- « allume la lampe » / « éteins la lampe »
- « monte le volume », « baisse le volume », « volume à 50 », « coupe le son »
- « mets en pause », « reprends la musique », « chanson suivante » (pour l'appli de musique active)
- « minuteur de 10 minutes », « annule le minuteur »
- « rappelle-moi dans 20 minutes de sortir le riz »
- « quelle heure est-il ? », « quel jour on est ? », « combien de batterie ? »
- « répète », « merci » ou « ok » (terminent la conversation), « éteins-toi » (arrête Jarvis)

Tout le reste est envoyé à Gemini.

## Conversation continue

Après chaque réponse (commande ou Gemini), Jarvis réécoute pendant **30 secondes** sans que tu redises « Jarvis ». Un silence ou une erreur de reconnaissance ne le coupe plus : il relance l'écoute tant que les 30 secondes ne sont pas écoulées, et le délai repart à zéro quand tu parles. Dis « merci » ou « ok » pour qu'il s'arrête (désactivable dans les réglages).

## Envoi automatique des messages WhatsApp

1. Appuie sur **Activer l'envoi WhatsApp automatique** et active « Jarvis (envoi WhatsApp) » dans les réglages d'accessibilité (une seule fois).
2. Dis « envoie un WhatsApp à Paul pour dire que j'arrive » et confirme.
3. Déverrouille ton téléphone avec ton code : WhatsApp s'ouvre sur la discussion et Jarvis appuie sur « Envoyer » (dans les 90 secondes suivant ta confirmation).

Sans l'accessibilité, la discussion s'ouvre avec le message prêt et tu appuies toi-même sur « Envoyer ».

## Ouvrir une appli depuis une autre appli, Spotify, SMS

- Android 10+ interdit à une appli en arrière-plan d'en ouvrir une autre. Pour que « ouvre Spotify » marche **depuis WhatsApp ou n'importe quelle appli** : active le service d'accessibilité Jarvis (bouton dans l'app) **et/ou** autorise « Afficher par-dessus d'autres applis ».
- Jarvis ne dit « message envoyé » que si l'envoi est confirmé : SMS accepté par l'opérateur, ou bouton « Envoyer » WhatsApp réellement pressé puis disparu. Une notification « Messages envoyés par Jarvis » reste comme preuve (les SMS envoyés par Jarvis n'apparaissent pas dans l'appli Messages : Android le réserve à l'appli SMS par défaut).
- Jarvis exécute entièrement une commande avant de rouvrir le micro : pas de bip, pas d'écoute tant que ce n'est pas fini.

## Notes

- Le mot de réveil est détecté localement avec Vosk (modèle anglais, grammaire limitée au mot « jarvis »). Tes phrases sont comprises par la reconnaissance vocale française d'Android.
- Le micro est coupé pendant que Jarvis parle. Toucher « Parler » l'interrompt.
- Android peut refuser d'ouvrir une appli depuis l'arrière-plan : dans ce cas Jarvis affiche une notification « Touche pour ouvrir… ». Autoriser « Afficher par-dessus d'autres applis » pour Jarvis peut aider.
- Spotify : « joue X sur Spotify » lance une recherche dans l'appli Spotify (aucune clé API). Pause, reprise et suivant passent par les touches média.
- Les minuteurs et rappels vivent dans le service : si tu arrêtes Jarvis, ils sont annulés.
- Android 14+ : démarre le service app ouverte, après chaque redémarrage du téléphone.
- L'APK est signé avec une clé fixe (app/debug.keystore) : les mises à jour s'installent par-dessus l'ancienne version.
