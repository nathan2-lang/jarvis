# Jarvis pour Android

Assistant vocal en arrière-plan : tu dis « Jarvis », puis ta question, et Claude te répond à voix haute.

## Ce qu'il te faut

1. **Android Studio** (dernière version stable).
2. Une **clé API Claude** : https://console.anthropic.com
3. Une **clé d'accès Picovoice** (gratuite, pour le mot de réveil) : https://console.picovoice.ai

## Installation

1. Décompresse le projet, puis dans Android Studio : *File > Open* et choisis le dossier `jarvis`.
2. Attends la fin de la synchronisation Gradle (elle télécharge Gradle et les dépendances).
3. Active le **mode développeur** et le **débogage USB** sur ton téléphone, branche-le, puis clique sur *Run*.
4. Dans l'app : colle tes deux clés, appuie sur **Démarrer Jarvis** et accepte les permissions (micro, notifications).
5. Appuie sur **Autoriser l'arrière-plan (batterie)** pour que le téléphone ne tue pas le service.

## Utilisation

Dis « Jarvis », attends l'écoute (la reconnaissance démarre juste après), pose ta question. La réponse est lue à voix haute, puis Jarvis se remet à écouter le mot de réveil. Un bouton *Arrêter* est dans la notification.

## Notes

- **Android 14+** : le service micro doit être démarré quand l'app est visible. C'est pourquoi on le lance depuis le bouton, et non en arrière-plan.
- Le mot de réveil « Jarvis » est détecté **localement**. Seule ta question, transcrite par le service vocal d'Android, est envoyée à Claude.
- Les clés sont stockées sur le téléphone, ce qui convient pour un usage personnel.
- Le modèle utilisé est défini dans `ClaudeClient.kt` (`MODEL`). Pour des réponses plus fines, remplace par `claude-sonnet-5-5`.
- Si Gradle se plaint d'une version de dépendance, mets-la à jour avec la suggestion d'Android Studio.

## Prochaines étapes

Ouvrir des apps, alarmes, appels, SMS, voix plus naturelle, démarrage au lancement du téléphone.
