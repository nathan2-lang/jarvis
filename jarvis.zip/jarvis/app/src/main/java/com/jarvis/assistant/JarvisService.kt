package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Service au premier plan : écoute le mot « Jarvis » en continu,
 * puis écoute la question, interroge Claude et répond à voix haute.
 */
class JarvisService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var porcupine: PorcupineManager? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var claude: ClaudeClient? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground("En attente de « Jarvis »…")

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val claudeKey = prefs.getString(KEY_CLAUDE, "").orEmpty()
        val picoKey = prefs.getString(KEY_PICOVOICE, "").orEmpty()
        if (claudeKey.isBlank() || picoKey.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (claude == null) claude = ClaudeClient(claudeKey)
        if (tts == null) initTts()
        if (porcupine == null) initWakeWord(picoKey)

        return START_STICKY
    }

    // ---------- Notification (obligatoire pour un service au premier plan) ----------

    private fun startAsForeground(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(0, "Arrêter", stop)
            .build()
        startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    // ---------- Mot de réveil ----------

    private fun initWakeWord(accessKey: String) {
        try {
            porcupine = PorcupineManager.Builder()
                .setAccessKey(accessKey)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(applicationContext, PorcupineManagerCallback { main.post { onWakeWord() } })
            porcupine?.start()
        } catch (e: Exception) {
            speak("Impossible de démarrer le mot de réveil. Vérifie ta clé Picovoice.")
            stopSelf()
        }
    }

    private fun onWakeWord() {
        // Le micro ne peut servir qu'à une seule chose à la fois.
        porcupine?.stop()
        main.postDelayed({ listen() }, 300)
    }

    private fun resumeWakeWord() {
        main.postDelayed({
            try { porcupine?.start() } catch (_: Exception) {}
        }, 300)
    }

    // ---------- Reconnaissance vocale ----------

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("La reconnaissance vocale n'est pas disponible sur ce téléphone.")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) resumeWakeWord() else askClaude(text)
            }

            override fun onError(error: Int) = resumeWakeWord()
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
        )
    }

    // ---------- Claude ----------

    private fun askClaude(question: String) {
        scope.launch {
            val reply = withContext(Dispatchers.IO) { claude?.ask(question) ?: "Claude n'est pas prêt." }
            speak(reply)
        }
    }

    // ---------- Synthèse vocale ----------

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.FRENCH
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { resumeWakeWord() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { resumeWakeWord() } }
                })
            }
        }
    }

    private fun speak(text: String) {
        val engine = tts
        if (engine == null) {
            resumeWakeWord()
            return
        }
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    // ---------- Arrêt ----------

    override fun onDestroy() {
        scope.cancel()
        main.removeCallbacksAndMessages(null)
        try { porcupine?.stop(); porcupine?.delete() } catch (_: Exception) {}
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val PREFS = "jarvis"
        const val KEY_CLAUDE = "claude_key"
        const val KEY_PICOVOICE = "picovoice_key"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        private const val CHANNEL_ID = "jarvis_channel"
        private const val NOTIF_ID = 1
    }
}
