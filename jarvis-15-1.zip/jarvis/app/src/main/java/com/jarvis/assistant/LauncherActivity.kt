package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * Ce qui s'ouvre quand tu touches l'icône Nova. Il n'affiche rien et se ferme tout de suite :
 *  - si Nova est prêt, il démarre l'écoute et la barre + la bulle apparaissent par-dessus ton écran
 *    (comme un assistant), sans ouvrir d'application ;
 *  - sinon (clé Gemini, micro ou affichage par-dessus les autres applis manquants), il t'amène
 *    là où il faut le régler.
 * Le grand écran de Nova reste accessible par un appui long sur l'icône (« Écran Nova »).
 */
class LauncherActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        route()
        finish()
        overridePendingTransition(0, 0)
    }

    private fun route() {
        val prefs = getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE)
        val hasKey = prefs.getString(JarvisService.KEY_API, "").orEmpty().isNotBlank()
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

        if (!hasKey || !micOk) {
            // Première utilisation : le grand écran guide (clé Gemini, micro).
            startActivity(Intent(this, MainActivity::class.java))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Autorise Nova à s'afficher par-dessus les autres applis, puis touche Nova de nouveau.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).setData(Uri.parse("package:$packageName"))
            )
            return
        }
        // Démarre Nova s'il est arrêté, et l'écoute tout de suite (comme un assistant).
        ContextCompat.startForegroundService(
            this,
            Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_LISTEN)
        )
    }
}
