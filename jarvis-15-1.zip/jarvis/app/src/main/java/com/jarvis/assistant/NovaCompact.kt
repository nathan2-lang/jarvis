package com.jarvis.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Les trois morceaux de la surcouche compacte de Nova (style assistant) :
 *  - [NovaBarView]    : la barre en bas (✕, phrase d'état, onde sonore) ;
 *  - [NovaBubbleView] : la bulle lumineuse au-dessus de la barre ;
 *  - [NovaCardView]   : la carte qui affiche la réponse pendant que Nova parle.
 * Chacune met à jour son contenu toute seule tant qu'elle est affichée.
 */

/** La barre du bas. Toucher la barre = parler à Nova ; ✕ = fermer. */
class NovaBarView(context: Context) : LinearLayout(context) {

    var onClose: (() -> Unit)? = null
    var onMic: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * density).toInt()

    private val closeButton = TextView(context)
    private val hint = TextView(context)
    private val wave = WaveIconView(context)
    private val stateListener: () -> Unit = { render() }

    init {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#F2121A2E"))
            cornerRadius = dp(28).toFloat()
            setStroke(dp(1), Color.parseColor("#4D6F8FD8"))
        }
        isClickable = true
        setOnClickListener { onMic?.invoke() }

        closeButton.apply {
            text = "✕"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTextColor(Color.parseColor("#9DB1D6"))
            gravity = Gravity.CENTER
            setOnClickListener { onClose?.invoke() }
        }
        addView(closeButton, LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.MATCH_PARENT))

        hint.apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.parseColor("#EAF0FB"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        addView(hint, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        addView(wave, LinearLayout.LayoutParams(dp(30), dp(30)).apply {
            leftMargin = dp(8)
            rightMargin = dp(20)
        })

        render()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        JarvisState.addListener(stateListener)
        render()
    }

    override fun onDetachedFromWindow() {
        JarvisState.removeListener(stateListener)
        super.onDetachedFromWindow()
    }

    fun render() {
        val phase = JarvisState.phase
        wave.active = phase == Phase.LISTENING
        val question = JarvisState.lastQuestion
        val quoted = if (question.isBlank()) "" else "« $question »"
        hint.text = when (phase) {
            Phase.LISTENING -> "Parle maintenant…"
            Phase.THINKING -> quoted.ifEmpty { "Je réfléchis…" }
            Phase.SPEAKING -> quoted.ifEmpty { "Nova te répond" }
            Phase.WAITING -> "Dis « Nova » ou touche ici"
            Phase.LOADING -> "Chargement…"
            Phase.STOPPED -> "Nova est arrêté"
        }
    }
}

/** La bulle lumineuse (fond transparent) : elle suit ce que fait Nova. */
class NovaBubbleView(context: Context) : FrameLayout(context) {

    private val orb = OrbView(context)
    private val stateListener: () -> Unit = { orb.setPhase(JarvisState.phase) }

    init {
        addView(
            orb,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        orb.setPhase(JarvisState.phase)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        JarvisState.addListener(stateListener)
        stateListener()
    }

    override fun onDetachedFromWindow() {
        JarvisState.removeListener(stateListener)
        super.onDetachedFromWindow()
    }
}

/** La carte de réponse : le texte que Nova est en train de dire. */
class NovaCardView(context: Context) : TextView(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * density).toInt()
    private val stateListener: () -> Unit = { render() }

    init {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        setLineSpacing(0f, 1.1f)
        maxLines = 7
        ellipsize = TextUtils.TruncateAt.END
        setPadding(dp(20), dp(16), dp(20), dp(16))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#F2121A2E"))
            cornerRadius = dp(24).toFloat()
            setStroke(dp(1), Color.parseColor("#4D6F8FD8"))
        }
        render()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        JarvisState.addListener(stateListener)
        render()
    }

    override fun onDetachedFromWindow() {
        JarvisState.removeListener(stateListener)
        super.onDetachedFromWindow()
    }

    fun render() {
        text = JarvisState.lastAnswer
    }
}
