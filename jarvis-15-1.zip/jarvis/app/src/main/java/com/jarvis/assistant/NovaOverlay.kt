package com.jarvis.assistant

import android.content.Context
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager

/**
 * Affiche Nova PAR-DESSUS l'appli en cours, comme un assistant, sans ouvrir d'application :
 *  - une barre compacte en bas de l'écran ;
 *  - la bulle lumineuse juste au-dessus ;
 *  - une carte avec la réponse pendant que Nova parle.
 * Chaque morceau est sa propre petite fenêtre, de la taille exacte de ce qu'on voit : le reste
 * de l'écran (tes applis) reste visible et utilisable. Nécessite l'autorisation
 * « Afficher par-dessus les autres applis ».
 */
class NovaOverlay(
    private val context: Context,
    private val onClose: () -> Unit,
    private val onMic: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = context.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * density).toInt()

    private var bar: NovaBarView? = null
    private var bubble: NovaBubbleView? = null
    private var card: NovaCardView? = null

    val isShown: Boolean get() = bar != null

    /** Peut être rappelé à chaque changement d'état : n'ajoute que ce qui manque. */
    fun show() {
        if (!Settings.canDrawOverlays(context)) return

        if (bar == null) {
            val b = NovaBarView(context)
            b.onClose = onClose
            b.onMic = onMic
            if (addWindow(b, screenWidth() - dp(32), dp(56), bottomMargin(), touchable = true)) bar = b

            val o = NovaBubbleView(context)
            if (addWindow(o, dp(170), dp(170), bottomMargin() + dp(20), touchable = false)) bubble = o
        }

        // La carte n'apparaît que pendant que Nova parle.
        val wantCard = JarvisState.phase == Phase.SPEAKING && JarvisState.lastAnswer.isNotBlank()
        if (wantCard) {
            if (card == null) {
                val c = NovaCardView(context)
                val added = addWindow(
                    c, screenWidth() - dp(32), ViewGroup.LayoutParams.WRAP_CONTENT,
                    bottomMargin() + dp(150), touchable = false
                )
                if (added) card = c
            }
        } else {
            fadeOutAndRemove(card)
            card = null
        }
    }

    fun hide() {
        fadeOutAndRemove(bar)
        fadeOutAndRemove(bubble)
        fadeOutAndRemove(card)
        bar = null
        bubble = null
        card = null
    }

    /** Retire tout de suite (arrêt du service). */
    fun hideNow() {
        removeNow(bar)
        removeNow(bubble)
        removeNow(card)
        bar = null
        bubble = null
        card = null
    }

    // ---------- Fenêtres ----------

    private fun addWindow(view: View, width: Int, height: Int, bottomOffset: Int, touchable: Boolean): Boolean {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        // Ce qui n'est qu'un dessin ne doit jamais bloquer un appui sur l'appli du dessous.
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE

        val params = WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = bottomOffset
        }
        return try {
            view.alpha = 0f
            windowManager.addView(view, params)
            view.animate().alpha(1f).setDuration(180).start()
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun fadeOutAndRemove(view: View?) {
        if (view == null) return
        view.animate().alpha(0f).setDuration(160).withEndAction {
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun removeNow(view: View?) {
        if (view == null) return
        try {
            view.animate().cancel()
            windowManager.removeView(view)
        } catch (_: Exception) {
        }
    }

    private fun screenWidth(): Int = context.resources.displayMetrics.widthPixels

    /** Distance entre le bas de l'écran et la barre : au-dessus de la barre de gestes. */
    private fun bottomMargin(): Int {
        val id = context.resources.getIdentifier("navigation_bar_height", "dimen", "android")
        val nav = if (id > 0) context.resources.getDimensionPixelSize(id) else 0
        return maxOf(nav, dp(24)) + dp(10)
    }
}
