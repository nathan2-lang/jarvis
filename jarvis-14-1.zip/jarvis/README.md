# Nova pour Android

Assistant vocal en français : dis « Nova », puis parle. Nova exécute les commandes du téléphone ou répond avec Gemini, à voix haute. Fonctionne écran verrouillé. Le bouton « Parler » de la notification reste disponible.

## Ce qu'il te faut

Une **clé API Gemini gratuite** : https://aistudio.google.com/apikey

## Utilisation

1. Ouvre l'app, touche la roue ⚙ en haut à droite, colle ta clé Gemini (et, si tu veux, ton prénom pour la salutation). Reviens, touche la barre du bas pour démarrer Nova et accepte les permissions (micro, contacts, appels, SMS).
2. Appuie sur **Autoriser l'arrière-plan (batterie)**.
3. Attends « Nova est prêt » (le premier démarrage charge le modèle, quelques secondes).
4. Dis « Nova », attends le bip, parle.

## L'interface

- **Écran principal** : fond sombre, bulle lumineuse au centre, salutation et barre « Dis Nova ou touche ici » en bas. La bulle respire en attente, gonfle et ondule avec ta voix quand il écoute, tourne vite quand il réfléchit et se déforme en vagues quand il parle.
- **Par-dessus les autres applis** : quand tu dis « Nova » depuis une autre appli, le même écran apparaît en bas de l'écran, sans ouvrir d'application (autorisation « Afficher par-dessus les autres applis » à donner dans les réglages). Touche ✕ pour le fermer. Si une commande ouvre une appli (« ouvre WhatsApp »), il s'efface pour ne pas la recouvrir.

## Si Nova ne réagit pas quand tu l'appelles

Le mot de réveil est écouté par un modèle **anglais**, qui entend « Nova » comme un mot proche. Dans les réglages, le champ « Mots de réveil » contient une liste de variantes (nova, novah, novo). Ajoute celles qui marchent pour ta voix, retire celles qui se déclenchent à tort, puis arrête et redémarre Nova.

## Commandes du téléphone (sans internet, sans Gemini)

- « ouvre WhatsApp », « lance YouTube »
- « appelle Maman », « appelle le 0102030405 »
- « envoie un SMS à Paul pour dire que j'arrive » (Nova demande confirmation avant d'envoyer)
- « envoie un WhatsApp à Paul pour dire que j'arrive » (confirmation, puis la discussion s'ouvre avec le message ; voir plus bas pour l'envoi automatique)
- « joue Burna Boy sur Spotify », « mets de la musique sur Spotify », « coupe la musique » / « mets Spotify en pause »
- « allume la lampe » / « éteins la lampe »
- « monte le volume », « baisse le volume », « volume à 50 », « coupe le son »
- « mets en pause », « reprends la musique », « chanson suivante » (pour l'appli de musique active)
- « minuteur de 10 minutes », « annule le minuteur »
- « rappelle-moi dans 20 minutes de sortir le riz »
- « quelle heure est-il ? », « quel jour on est ? », « combien de batterie ? »
- « répète », « merci » ou « ok » (terminent la conversation), « éteins-toi » (arrête Nova)

Tout le reste est envoyé à Gemini.

## Conversation continue

Après chaque réponse (commande ou Gemini), Nova réécoute pendant **30 secondes** sans que tu redises « Nova ». Un silence ou une erreur de reconnaissance ne le coupe plus : il relance l'écoute tant que les 30 secondes ne sont pas écoulées, et le délai repart à zéro quand tu parles. Dis « merci » ou « ok » pour qu'il s'arrête (désactivable dans les réglages).

## Envoi automatique des messages WhatsApp

1. Appuie sur **Activer l'envoi WhatsApp automatique** et active « Nova (envoi WhatsApp) » dans les réglages d'accessibilité (une seule fois).
2. Dis « envoie un WhatsApp à Paul pour dire que j'arrive » et confirme.
3. Déverrouille ton téléphone avec ton code : WhatsApp s'ouvre sur la discussion et Nova appuie sur « Envoyer » (dans les 90 secondes suivant ta confirmation).

Sans l'accessibilité, la discussion s'ouvre avec le message prêt et tu appuies toi-même sur « Envoyer ».

## Ouvrir une appli depuis une autre appli, Spotify, SMS

- Android 10+ interdit à une appli en arrière-plan d'en ouvrir une autre. Pour que « ouvre Spotify » marche **depuis WhatsApp ou n'importe quelle appli** : active le service d'accessibilité Nova (bouton dans l'app) **et/ou** autorise « Afficher par-dessus d'autres applis ».
- Nova ne dit « message envoyé » que si l'envoi est confirmé : SMS accepté par l'opérateur, ou bouton « Envoyer » WhatsApp réellement pressé puis disparu. Une notification « Messages envoyés par Nova » reste comme preuve (les SMS envoyés par Nova n'apparaissent pas dans l'appli Messages : Android le réserve à l'appli SMS par défaut).
- Nova exécute entièrement une commande avant de rouvrir le micro : pas de bip, pas d'écoute tant que ce n'est pas fini.

## Agenda, alarmes, rappels

- « mets un rendez-vous chez le dentiste demain à 14h » → ajouté à ton agenda (avec une alerte 15 min avant), puis relu dans l'agenda pour vérifier.
- « rappelle-moi lundi à 9h d'appeler Paul » → évènement avec alerte dans ton agenda (marche même si Nova est arrêté).
- « réveille-moi à 7h30 » → alarme dans l'appli Horloge.
- « qu'est-ce que j'ai demain à l'agenda ? » → Nova lit tes évènements.
- Il faut autoriser l'agenda (bouton « Autoriser contacts, appels, SMS et agenda »). Les dates sont calculées par Gemini : il faut donc une connexion internet.

## Exécuter tout ce que tu dis

- Nova comprend les formulations libres : « peux-tu envoyer… », « dis à Paul que… sur WhatsApp », « s'il te plaît », etc. Ce que les règles locales ne reconnaissent pas est converti en commande par Gemini, puis exécuté.
- S'il manque une info, il la demande au lieu d'abandonner : « envoie un message à quelqu'un sur WhatsApp » → « À qui ? » → « Que dois-je lui dire ? » → confirmation → envoi. Dis « annule » pour arrêter.

## Notes

- Le mot de réveil est détecté localement avec Vosk (modèle anglais, grammaire limitée aux mots de la liste « Mots de réveil »). Tes phrases sont comprises par la reconnaissance vocale française d'Android.
- Le micro est coupé pendant que Nova parle. Toucher « Parler » l'interrompt.
- Android peut refuser d'ouvrir une appli depuis l'arrière-plan : dans ce cas Nova affiche une notification « Touche pour ouvrir… ». Autoriser « Afficher par-dessus d'autres applis » pour Nova peut aider.
- Spotify : « joue X sur Spotify » lance une recherche dans l'appli Spotify (aucune clé API). Pause, reprise et suivant passent par les touches média.
- Les minuteurs et rappels vivent dans le service : si tu arrêtes Nova, ils sont annulés.
- Android 14+ : démarre le service app ouverte, après chaque redémarrage du téléphone.
- L'APK est signé avec une clé fixe (app/debug.keystore) : les mises à jour s'installent par-dessus l'ancienne version.
