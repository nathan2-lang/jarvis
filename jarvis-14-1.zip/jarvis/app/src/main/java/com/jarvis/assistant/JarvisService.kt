package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener as VoskListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.IOException
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Service au premier plan.
 * - Écoute en continu le mot « Nova » (Vosk, hors ligne).
 * - Après le mot de réveil (ou un appui sur « Parler »), écoute la phrase.
 * - Si c'est une commande du téléphone (PhoneActions), l'exécute ; sinon l'envoie à Gemini.
 * - Lit la réponse à voix haute, puis (option) écoute la suite sans redire « Nova ».
 */
class JarvisService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var gemini: GeminiClient? = null
    private var currentKey = ""
    private var actions: PhoneActions? = null

    // Mot de réveil
    private var model: Model? = null
    private var wakeRecognizer: Recognizer? = null
    private var wakeService: SpeechService? = null
    private var wakeFired = false
    private var wakeSet: Set<String> = emptySet()
    private var modelLoading = false

    /** Vrai pendant l'écoute de la phrase et l'attente de la réponse. */
    private var busy = false

    /** Vrai pendant que Nova parle. */
    private var speaking = false

    /**
     * Vrai depuis que ta phrase est reçue jusqu'à ce que la commande soit TERMINÉE (et le résultat annoncé).
     * Pendant ce temps, le micro est fermé : aucune nouvelle phrase n'est écoutée, pas de bip.
     */
    private var executing = false

    private var listenAfterSpeech = false
    private var shutdownAfterSpeech = false

    /** Fin de la fenêtre d'écoute (SystemClock.elapsedRealtime) : Nova réécoute jusque-là. */
    private var sessionDeadline = 0L

    /** Question de confirmation en attente (ex. envoi d'un SMS). */
    private var pending: Outcome.Confirm? = null

    /** Question ouverte en attente (ex. « Que dois-je lui dire ? »). */
    private var pendingAsk: Outcome.Ask? = null
    private var lastAnswer = ""

    private val timers = CopyOnWriteArrayList<Runnable>()

    /** Surcouche Nova affichée par-dessus les autres applis pendant une conversation. */
    private var overlay: NovaOverlay? = null
    private val stateListener: () -> Unit = { syncOverlay() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        overlay = NovaOverlay(this, onClose = { dismissSession() }, onMic = { startListening() })
        JarvisState.addListener(stateListener)
        actions = PhoneActions(
            context = applicationContext,
            schedule = { delayMs, spoken -> scheduleSpoken(delayMs, spoken) },
            cancelTimers = { cancelAllTimers() },
            announce = { speakInterim(it) }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            startAsForeground()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val apiKey = prefs.getString(KEY_API, "").orEmpty()
        if (apiKey.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (gemini == null || apiKey != currentKey) {
            gemini = GeminiClient(apiKey)
            currentKey = apiKey
        }
        if (tts == null) initTts()
        if (model == null) {
            JarvisState.setPhase(Phase.LOADING)
            loadModel()
        }

        if (intent?.action == ACTION_LISTEN) startListening()
        else if (model != null) startWake()

        return START_STICKY
    }

    // ---------- Notification (obligatoire pour un service au premier plan) ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Nova", NotificationManager.IMPORTANCE_LOW)
        )
        val listen = serviceIntent(ACTION_LISTEN, 1)
        val stop = serviceIntent(ACTION_STOP, 2)

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Nova")
            .setContentText("Dis « Nova » ou appuie sur « Parler »")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(listen)
            .addAction(0, "Parler", listen)
            .addAction(0, "Arrêter", stop)
            .build()
        startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun serviceIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(
            this, requestCode,
            Intent(this, JarvisService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE
        )

    // ---------- Mot de réveil (Vosk) ----------

    private fun loadModel() {
        if (modelLoading) return
        modelLoading = true
        StorageService.unpack(
            this, "model-en", "model",
            StorageService.Callback<Model> { m ->
                main.post {
                    model = m
                    modelLoading = false
                    if (!busy) say("Nova est prêt.")
                }
            },
            StorageService.Callback<IOException> {
                main.post {
                    modelLoading = false
                    if (!busy) say("Je n'ai pas pu charger le mot de réveil. Utilise le bouton Parler.")
                }
            }
        )
    }

    private fun startWake() {
        if (busy || speaking || wakeService != null) return
        val m = model ?: return
        try {
            val words = wakeWords()
            wakeSet = words.toSet()
            val grammar = JSONArray().apply {
                words.forEach { put(it) }
                put("[unk]")
            }.toString()
            val rec = Recognizer(m, 16000f, grammar)
            val svc = SpeechService(rec, 16000f)
            wakeFired = false
            svc.startListening(object : VoskListener {
                override fun onPartialResult(hypothesis: String?) = checkWake(hypothesis)
                override fun onResult(hypothesis: String?) = checkWake(hypothesis)
                override fun onFinalResult(hypothesis: String?) {}
                override fun onError(exception: Exception?) {
                    // Le micro a eu un problème : on relance l'écoute du mot de réveil.
                    main.post { restartWake() }
                }
                override fun onTimeout() {}
            })
            wakeRecognizer = rec
            wakeService = svc
            JarvisState.setPhase(Phase.WAITING)
        } catch (_: Exception) {
            // Le bouton « Parler » reste disponible.
        }
    }

    private fun restartWake() {
        stopWake()
        main.postDelayed({ startWake() }, 1500)
    }

    private fun checkWake(hypothesis: String?) {
        if (wakeFired || hypothesis == null) return
        val text = try {
            val json = JSONObject(hypothesis)
            json.optString("partial").ifEmpty { json.optString("text") }
        } catch (_: Exception) {
            hypothesis
        }
        val heard = text.lowercase(Locale.ROOT).split(' ').filter { it.isNotEmpty() }
        if (heard.any { it in wakeSet }) {
            wakeFired = true
            main.post { startListening() }
        }
    }

    /**
     * Mots qui déclenchent Nova. Le modèle de reconnaissance est anglais : il entend « Nova »
     * comme un mot anglais proche (novah, novo…). La liste se règle dans les réglages de l'appli.
     */
    private fun wakeWords(): List<String> {
        val raw = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_WAKE, DEFAULT_WAKE).orEmpty()
        val list = raw.split(',', ';', '\n')
            .map { PhoneActions.norm(it) }
            .filter { it.isNotEmpty() && !it.contains(' ') }
            .distinct()
        return list.ifEmpty { DEFAULT_WAKE.split(',').map { it.trim() } }
    }

    private fun stopWake() {
        try {
            wakeService?.stop()
            wakeService?.shutdown()
        } catch (_: Exception) {}
        try { wakeRecognizer?.close() } catch (_: Exception) {}
        wakeService = null
        wakeRecognizer = null
    }

    /** Remet Nova en attente du mot de réveil. */
    private fun resume() {
        busy = false
        executing = false
        speaking = false
        pending = null
        pendingAsk = null
        listenAfterSpeech = false
        main.postDelayed({ startWake() }, 400)
    }

    // ---------- Reconnaissance vocale (la phrase) ----------

    private fun startListening(fresh: Boolean = true) {
        if (busy || executing) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("La reconnaissance vocale n'est pas disponible sur ce téléphone.")
            return
        }
        if (speaking) {
            tts?.stop()
            speaking = false
        }
        busy = true
        listenAfterSpeech = false
        // Un « Nova » ou un appui sur le micro (pas une simple écoute de suite) ramène la surcouche.
        if (fresh) JarvisState.setOverlaySuppressed(false)
        // Fenêtre d'écoute de 30 s : tant qu'elle n'est pas écoulée, Nova relance l'écoute
        // après un silence ou une erreur, au lieu de retourner attendre « Nova ».
        sessionDeadline = SystemClock.elapsedRealtime() + SESSION_MS
        stopWake()
        JarvisState.setPhase(Phase.LISTENING)

        // Petit bip pour signaler que Nova écoute.
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        } catch (_: Exception) {}

        main.postDelayed({ beginRecognition() }, 400)
    }

    private fun beginRecognition() {
        if (executing) return
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) {
                    retryOrResume(250)
                } else {
                    // Tu as parlé : la fenêtre de 30 s repart de zéro.
                    sessionDeadline = SystemClock.elapsedRealtime() + SESSION_MS
                    handleUtterance(text)
                }
            }

            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    resume()
                } else {
                    // Silence, rien compris, reconnaisseur occupé… : on réessaie tant qu'il reste du temps.
                    retryOrResume(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 900 else 250)
                }
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                JarvisState.setLevelFromRms(rmsdB)
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                // Laisse-moi finir ma phrase, même avec une petite pause.
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            }
        )
    }

    /** Relance l'écoute s'il reste du temps dans la fenêtre de 30 s, sinon retourne attendre « Nova ». */
    private fun retryOrResume(delayMs: Long) {
        if (!busy || executing) return
        if (SystemClock.elapsedRealtime() < sessionDeadline) {
            main.postDelayed({ if (busy && !executing) beginRecognition() }, delayMs)
        } else {
            resume()
        }
    }

    // ---------- Traitement de la phrase : confirmation, commande locale, ou Gemini ----------

    private fun handleUtterance(text: String) {
        // Dès qu'une phrase est reçue : on ferme le micro et on ne réécoute qu'après l'exécution complète.
        executing = true
        main.post { recognizer?.destroy(); recognizer = null }
        JarvisState.update(question = text, answer = "")
        JarvisState.setPhase(Phase.THINKING)

        val waiting = pending
        pending = null
        val asking = pendingAsk
        pendingAsk = null

        scope.launch {
            val outcome: Outcome = withContext(Dispatchers.IO) {
                when {
                    waiting != null ->
                        if (PhoneActions.isYes(text)) Outcome.Say(waiting.onYes())
                        else Outcome.Say("D'accord, j'annule.")
                    asking != null ->
                        if (PhoneActions.norm(text) in CANCEL_WORDS) Outcome.Say("D'accord, j'annule.")
                        else asking.next(text)
                    PhoneActions.norm(text) in REPEAT_WORDS ->
                        Outcome.Say(lastAnswer.ifBlank { "Je n'ai rien à répéter." })
                    else -> actions?.handle(text) ?: Outcome.None
                }
            }
            deliver(outcome, text)
        }
    }

    /** Dit le résultat d'une commande, ou passe la main à Gemini si ce n'était pas une commande. */
    private fun deliver(outcome: Outcome, text: String) {
        when (outcome) {
            is Outcome.Say -> say(
                outcome.text,
                // Après une commande, Nova réécoute 30 s sans redire « Nova »,
                // sauf après « merci » / « ok » ou quand on l'éteint.
                listenAfter = followUpEnabled() && !outcome.endSession && !outcome.shutdown,
                shutdown = outcome.shutdown
            )
            is Outcome.Confirm -> {
                pending = outcome
                say(outcome.prompt, listenAfter = true)
            }
            is Outcome.Ask -> {
                pendingAsk = outcome
                say(outcome.prompt, listenAfter = true)
            }
            is Outcome.None -> askGemini(text)
        }
    }

    private fun askGemini(question: String) {
        scope.launch {
            val reply = withContext(Dispatchers.IO) {
                gemini?.ask(question) ?: GeminiReply("Nova n'est pas prêt.", false)
            }
            // Gemini a reconnu une commande que les règles locales n'ont pas comprise : on l'exécute.
            if (reply.ok && reply.text.startsWith(GeminiClient.COMMAND_PREFIX)) {
                val cmd = reply.text.removePrefix(GeminiClient.COMMAND_PREFIX).trim().lines().first()
                val outcome = withContext(Dispatchers.IO) { actions?.handle(cmd) ?: Outcome.None }
                if (outcome is Outcome.None) {
                    say("Je n'ai pas compris cette commande. Peux-tu la reformuler ?", listenAfter = followUpEnabled())
                } else {
                    deliver(outcome, cmd)
                }
                return@launch
            }
            say(reply.text, listenAfter = reply.ok && followUpEnabled())
        }
    }

    private fun followUpEnabled(): Boolean =
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_FOLLOWUP, true)

    // ---------- Minuteurs et rappels ----------

    private fun scheduleSpoken(delayMs: Long, text: String) {
        val r = object : Runnable {
            override fun run() {
                // Ne coupe pas la parole : on réessaie dans quelques secondes.
                if (busy || speaking) {
                    main.postDelayed(this, 4000)
                    return
                }
                timers.remove(this)
                say(text)
            }
        }
        timers.add(r)
        main.postDelayed(r, delayMs)
    }

    private fun cancelAllTimers(): Int {
        val n = timers.size
        timers.forEach { main.removeCallbacks(it) }
        timers.clear()
        return n
    }

    // ---------- Surcouche ----------

    /** Montre la surcouche pendant l'écoute, la réflexion et la réponse ; la cache le reste du temps. */
    private fun syncOverlay() {
        val phase = JarvisState.phase
        val active = phase == Phase.LISTENING || phase == Phase.THINKING || phase == Phase.SPEAKING
        if (active && !JarvisState.screenVisible && !JarvisState.overlaySuppressed) overlay?.show()
        else overlay?.hide()
    }

    /** Croix de la surcouche : on la ferme, on coupe la parole et l'écoute, et on retourne attendre « Nova ». */
    private fun dismissSession() {
        JarvisState.setOverlaySuppressed(true)
        tts?.stop()
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        resume()
    }

    // ---------- Synthèse vocale ----------

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.FRENCH
                pickBestVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { if (utteranceId == "jarvis") main.post { afterSpeech() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { if (utteranceId == "jarvis") main.post { afterSpeech() } }
                })
                ttsReady = true
            }
        }
    }

    /** Prend la voix française installée de meilleure qualité qui marche sans internet. */
    private fun pickBestVoice() {
        try {
            val best = tts?.voices
                ?.filter {
                    it.locale.language == "fr" &&
                        !it.isNetworkConnectionRequired &&
                        it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
                }
                ?.maxWithOrNull(compareBy({ it.locale.country == "FR" }, { it.quality }))
            if (best != null) tts?.voice = best
        } catch (_: Exception) {}
    }

    /** Nova dit [text]. [listenAfter] : écoute la suite ensuite. [shutdown] : s'arrête ensuite. */
    private fun say(text: String, listenAfter: Boolean = false, shutdown: Boolean = false) {
        busy = false
        executing = false
        lastAnswer = text
        JarvisState.update(answer = text)
        listenAfterSpeech = listenAfter
        shutdownAfterSpeech = shutdown
        speak(text)
    }

    /** Phrase intermédiaire pendant une commande (ex. « Déverrouille ton téléphone ») : ne relance pas l'écoute. */
    private fun speakInterim(text: String) {
        main.post {
            if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "interim")
        }
    }

    private fun speak(text: String) {
        // Le micro est coupé pendant que Nova parle, pour qu'il ne s'entende pas lui-même.
        stopWake()
        if (!ttsReady) {
            afterSpeech()
            return
        }
        speaking = true
        JarvisState.setPhase(Phase.SPEAKING)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun afterSpeech() {
        speaking = false
        when {
            shutdownAfterSpeech -> stopSelf()
            listenAfterSpeech -> {
                listenAfterSpeech = false
                startListening(fresh = false)
            }
            else -> resume()
        }
    }

    // ---------- Arrêt ----------

    override fun onDestroy() {
        JarvisState.setPhase(Phase.STOPPED)
        JarvisState.removeListener(stateListener)
        overlay?.hideNow()
        overlay = null
        scope.cancel()
        main.removeCallbacksAndMessages(null)
        timers.clear()
        stopWake()
        try { model?.close() } catch (_: Exception) {}
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val PREFS = "jarvis"
        const val KEY_API = "gemini_key"
        const val KEY_FOLLOWUP = "followup"
        const val KEY_NAME = "user_name"
        // Nouvelle clé : la liste enregistrée pour l'ancien mot de réveil n'est pas reprise.
        const val KEY_WAKE = "wake_words_nova"
        const val DEFAULT_WAKE = "nova, novah, novo"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        const val ACTION_LISTEN = "com.jarvis.assistant.LISTEN"
        private const val CHANNEL_ID = "jarvis_channel"
        private const val NOTIF_ID = 1

        /** Durée pendant laquelle Nova réécoute après ta dernière parole ou sa réponse. */
        private const val SESSION_MS = 30_000L
        private val CANCEL_WORDS = setOf("annule", "laisse tomber", "non", "stop", "oublie", "ca va pas", "non merci")
        private val REPEAT_WORDS = setOf("repete", "repete moi ca", "tu peux repeter", "peux tu repeter", "redis")
    }
}
