package com.jarvis.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.sin

/**
 * L'interface de Nova : fond sombre, bulle lumineuse au centre, salutation, grande phrase
 * et barre « demande-moi quelque chose » en bas.
 *
 * Le même écran sert à deux endroits :
 *  - [isOverlay] = false : écran principal de l'appli (plein écran) ;
 *  - [isOverlay] = true  : surcouche affichée par-dessus n'importe quelle appli quand tu dis « Nova ».
 */
class NovaPanel(context: Context, private val isOverlay: Boolean) : FrameLayout(context) {

    /** Touche sur la croix (surcouche). */
    var onClose: (() -> Unit)? = null

    /** Touche sur la barre du bas : parler à Nova. */
    var onBarClick: (() -> Unit)? = null

    /** Touche sur la roue des réglages (écran principal). */
    var onSettings: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * density).toInt()

    private val orb = OrbView(context)
    private val wave = WaveIconView(context)
    private val greeting = TextView(context)
    private val headline = TextView(context)
    private val hint = TextView(context)

    private val stateListener: () -> Unit = { render() }

    init {
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            if (isOverlay) {
                intArrayOf(
                    Color.parseColor("#00000000"), Color.parseColor("#E6020612"),
                    Color.parseColor("#F2051338"), Color.parseColor("#FF0A2A6B")
                )
            } else {
                intArrayOf(
                    Color.parseColor("#000000"), Color.parseColor("#02050E"),
                    Color.parseColor("#05143A"), Color.parseColor("#0A2E78")
                )
            }
        )
        setPadding(0, 0, 0, dp(if (isOverlay) 28 else 14))

        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        content.addView(space(if (isOverlay) 0.35f else 1f))

        val orbSize = dp(if (isOverlay) 210 else 290)
        content.addView(orb, LinearLayout.LayoutParams(orbSize, orbSize))

        greeting.apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(Color.parseColor("#9DB1D6"))
            gravity = Gravity.CENTER
        }
        content.addView(greeting, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(if (isOverlay) 0 else 4) })

        headline.apply {
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = if (isOverlay) 5 else 9
            ellipsize = TextUtils.TruncateAt.END
            setLineSpacing(0f, 1.1f)
        }
        content.addView(headline, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(8)
            leftMargin = dp(28)
            rightMargin = dp(28)
        })

        content.addView(space(if (isOverlay) 0.5f else 1.2f))

        // Barre du bas
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), 0, dp(18), 0)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#B32B5FD0"), Color.parseColor("#CC9CC4FF"))
            ).apply {
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), Color.parseColor("#44FFFFFF"))
            }
            isClickable = true
            setOnClickListener { onBarClick?.invoke() }
        }
        hint.apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.parseColor("#F0F6FF"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        bar.addView(hint, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(wave, LinearLayout.LayoutParams(dp(30), dp(30)))
        content.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply {
            leftMargin = dp(20)
            rightMargin = dp(20)
        })

        // Bouton en haut à droite : croix (surcouche) ou réglages (écran principal)
        val top = TextView(context).apply {
            text = if (isOverlay) "✕" else "⚙︎"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setTextColor(Color.parseColor("#9DB1D6"))
            gravity = Gravity.CENTER
            setOnClickListener { if (isOverlay) onClose?.invoke() else onSettings?.invoke() }
        }
        addView(top, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(if (isOverlay) 6 else 4)
            rightMargin = dp(10)
        })

        // Laisse de la place aux barres du système (heure en haut, gestes en bas).
        ViewCompat.setOnApplyWindowInsetsListener(this) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            setPadding(b.left, if (isOverlay) 0 else b.top, b.right, b.bottom + dp(if (isOverlay) 22 else 14))
            insets
        }

        render()
    }

    private fun space(weight: Float) = View(context).also {
        it.layoutParams = LinearLayout.LayoutParams(0, 0, weight)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        JarvisState.addListener(stateListener)
        ViewCompat.requestApplyInsets(this)
        render()
    }

    override fun onDetachedFromWindow() {
        JarvisState.removeListener(stateListener)
        super.onDetachedFromWindow()
    }

    /** Met l'écran à jour selon ce que fait Nova. */
    fun render() {
        val phase = JarvisState.phase
        orb.setPhase(phase)
        wave.active = phase == Phase.LISTENING

        greeting.text = greetingText()

        val question = JarvisState.lastQuestion
        val quoted = if (question.isBlank()) "" else "« $question »"

        val main: String
        val bar: String
        when (phase) {
            Phase.STOPPED -> {
                main = "Nova est arrêté"
                bar = "Touche ici pour démarrer"
            }
            Phase.LOADING -> {
                main = "Je me réveille…"
                bar = "Chargement…"
            }
            Phase.WAITING -> {
                main = "Comment puis-je t'aider ?"
                bar = "Dis « Nova » ou touche ici"
            }
            Phase.LISTENING -> {
                main = "Je t'écoute…"
                bar = "Parle maintenant…"
            }
            Phase.THINKING -> {
                main = "Je réfléchis…"
                bar = quoted.ifEmpty { "…" }
            }
            Phase.SPEAKING -> {
                main = JarvisState.lastAnswer.ifBlank { "…" }
                bar = quoted.ifEmpty { "…" }
            }
        }

        headline.text = main
        headline.setTextSize(
            TypedValue.COMPLEX_UNIT_SP,
            when {
                main.length <= 40 -> if (isOverlay) 24f else 28f
                main.length <= 120 -> if (isOverlay) 19f else 22f
                else -> if (isOverlay) 16f else 18f
            }
        )
        hint.text = bar
    }

    private fun greetingText(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val hello = if (hour in 5..17) "Bonjour" else "Bonsoir"
        val name = context.getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE)
            .getString(JarvisService.KEY_NAME, "").orEmpty().trim()
        return if (name.isEmpty()) hello else "$hello $name"
    }
}

/** Petite icône « onde sonore » de la barre du bas ; elle bouge quand Nova écoute. */
class WaveIconView(context: Context) : View(context) {

    var active: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F2F7FF")
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val base = floatArrayOf(0.35f, 0.7f, 1f, 0.6f, 0.4f)
    private val startNanos = System.nanoTime()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val t = (System.nanoTime() - startNanos) / 1_000_000_000f
        val w = width.toFloat()
        val h = height.toFloat()
        paint.strokeWidth = w * 0.09f
        val gap = w / base.size
        for (i in base.indices) {
            var k = base[i]
            if (active) k *= 0.45f + 0.55f * abs(sin(t * 9f + i * 1.3f))
            val len = h * 0.8f * k
            val x = gap * (i + 0.5f)
            canvas.drawLine(x, h / 2f - len / 2f, x, h / 2f + len / 2f, paint)
        }
        if (active) postInvalidateOnAnimation()
    }
}
