package com.jarvis.assistant

import android.content.Context
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager

/**
 * Affiche l'interface de Nova PAR-DESSUS l'appli en cours (comme un assistant), sans ouvrir
 * d'application. Nécessite l'autorisation « Afficher par-dessus les autres applis ».
 * La fenêtre ne couvre que le bas de l'écran : le haut reste visible et utilisable.
 */
class NovaOverlay(
    private val context: Context,
    private val onClose: () -> Unit,
    private val onMic: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var panel: NovaPanel? = null

    val isShown: Boolean get() = panel != null

    fun show() {
        if (panel != null) return
        if (!Settings.canDrawOverlays(context)) return

        val view = NovaPanel(context, isOverlay = true)
        view.onClose = onClose
        view.onBarClick = onMic

        val height = (context.resources.displayMetrics.heightPixels * 0.66f).toInt()
        val params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
        }

        try {
            view.alpha = 0f
            windowManager.addView(view, params)
            panel = view
            view.animate().alpha(1f).setDuration(200).start()
        } catch (_: Exception) {
            panel = null
        }
    }

    fun hide() {
        val view = panel ?: return
        panel = null
        view.animate().alpha(0f).setDuration(160).withEndAction {
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
            }
        }.start()
    }

    /** Retire la fenêtre tout de suite (arrêt du service). */
    fun hideNow() {
        val view = panel ?: return
        panel = null
        try {
            view.animate().cancel()
            windowManager.removeView(view)
        } catch (_: Exception) {
        }
    }
}
