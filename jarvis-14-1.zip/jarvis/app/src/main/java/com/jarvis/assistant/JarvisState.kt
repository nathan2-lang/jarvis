package com.jarvis.assistant

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

/** Ce que fait Nova en ce moment (affiché dans l'écran principal et dans la surcouche). */
enum class Phase { STOPPED, LOADING, WAITING, LISTENING, THINKING, SPEAKING }

/** État partagé entre le service (qui écoute et parle) et les écrans. */
object JarvisState {
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<() -> Unit>()

    @Volatile
    var phase: Phase = Phase.STOPPED
        private set

    @Volatile
    var lastQuestion: String = ""
        private set

    @Volatile
    var lastAnswer: String = ""
        private set

    /** Volume de ta voix, de 0 à 1 (lissé). Sert à animer la bulle quand Nova t'écoute. */
    @Volatile
    var level: Float = 0f
        private set

    /** Vrai quand l'écran principal de Nova est affiché (la surcouche reste alors cachée). */
    @Volatile
    var screenVisible: Boolean = false
        private set

    fun setScreenVisible(value: Boolean) {
        screenVisible = value
        notifyChanged()
    }

    /**
     * Vrai après qu'une commande a ouvert une autre appli : la surcouche se cache pour ne pas
     * la recouvrir. Elle revient au prochain « Nova ».
     */
    @Volatile
    var overlaySuppressed: Boolean = false
        private set

    fun setOverlaySuppressed(value: Boolean) {
        overlaySuppressed = value
        notifyChanged()
    }

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    fun setPhase(p: Phase) {
        phase = p
        if (p != Phase.LISTENING) level = 0f
        notifyChanged()
    }

    fun update(question: String? = null, answer: String? = null) {
        if (question != null) lastQuestion = question
        if (answer != null) lastAnswer = answer
        notifyChanged()
    }

    /** [rmsdB] vient de SpeechRecognizer.onRmsChanged (environ -2 à 10). */
    fun setLevelFromRms(rmsdB: Float) {
        val target = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        // Montée rapide, descente douce : la bulle ne tremble pas.
        level = if (target > level) level + (target - level) * 0.6f else level + (target - level) * 0.15f
    }

    private fun notifyChanged() {
        main.post { listeners.forEach { it.invoke() } }
    }
}
