package com.jarvis.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.view.View

/** Dessine la main virtuelle (squelette lumineux) et le curseur par-dessus un fond sombre. */
class HandOverlayView(context: Context) : View(context) {

    private var hands: List<List<PointF>> = emptyList()
    private var cursor: PointF? = null
    private var mode = HandMode.NONE

    private val density = resources.displayMetrics.density

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 12f * density
        strokeCap = Paint.Cap.ROUND
        color = Color.argb(55, 34, 211, 238)
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        strokeCap = Paint.Cap.ROUND
        color = Color.argb(210, 34, 211, 238)
    }
    private val jointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(230, 34, 211, 238)
    }
    private val tipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(245, 230, 237, 247)
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
        color = Color.argb(230, 34, 211, 238)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(90, 34, 211, 238)
    }

    fun update(newHands: List<List<PointF>>, newCursor: PointF?, newMode: HandMode) {
        hands = newHands
        cursor = newCursor
        mode = newMode
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        for (hand in hands) {
            if (hand.size < 21) continue
            for (c in CONNECTIONS) {
                val a = hand[c[0]]
                val b = hand[c[1]]
                canvas.drawLine(a.x * w, a.y * h, b.x * w, b.y * h, glowPaint)
                canvas.drawLine(a.x * w, a.y * h, b.x * w, b.y * h, linePaint)
            }
            for (i in 0..20) {
                val p = hand[i]
                val tip = i == 4 || i == 8 || i == 12 || i == 16 || i == 20
                canvas.drawCircle(p.x * w, p.y * h, (if (tip) 5f else 3f) * density, if (tip) tipPaint else jointPaint)
            }
        }

        val c = cursor
        if (c != null && hands.isNotEmpty()) {
            val r = when (mode) {
                HandMode.PINCH -> 16f
                HandMode.FIST -> 10f
                else -> 24f
            } * density
            if (mode == HandMode.PINCH) canvas.drawCircle(c.x * w, c.y * h, r, fillPaint)
            canvas.drawCircle(c.x * w, c.y * h, r, ringPaint)
        }
    }

    companion object {
        private val CONNECTIONS = arrayOf(
            intArrayOf(0, 1), intArrayOf(1, 2), intArrayOf(2, 3), intArrayOf(3, 4),
            intArrayOf(0, 5), intArrayOf(5, 6), intArrayOf(6, 7), intArrayOf(7, 8),
            intArrayOf(5, 9), intArrayOf(9, 10), intArrayOf(10, 11), intArrayOf(11, 12),
            intArrayOf(9, 13), intArrayOf(13, 14), intArrayOf(14, 15), intArrayOf(15, 16),
            intArrayOf(13, 17), intArrayOf(17, 18), intArrayOf(18, 19), intArrayOf(19, 20),
            intArrayOf(0, 17)
        )
    }
}
