package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PointF
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Étape 1 : essai de la main virtuelle.
 * La caméra frontale voit ta main, qui est dessinée en lumière à l'écran.
 * Rien n'est encore contrôlé : on vérifie seulement que la main et les gestes sont bien reconnus.
 */
class HandActivity : AppCompatActivity() {

    private lateinit var overlay: HandOverlayView
    private lateinit var status: TextView
    private lateinit var tracker: HandTracker
    private val gestures = HandGestures()
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null

    private val density by lazy { resources.displayMetrics.density }
    private fun dp(v: Int): Int = (v * density).toInt()

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startTracking() else say("Caméra refusée. Autorise-la dans les réglages d'Android pour utiliser la main virtuelle.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        root.setBackgroundColor(BG)

        overlay = HandOverlayView(this)
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "←"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        header.addView(TextView(this).apply {
            text = "Main virtuelle (essai)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTextColor(TEXT)
            setPadding(dp(8), 0, 0, 0)
        })
        root.addView(header, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        status = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            text = "Démarrage de la caméra…"
        }
        footer.addView(status)
        footer.addView(TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(MUTED)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
            text = "Main ouverte : le cercle te suit · Pince le pouce et l'index : le cercle se remplit · Poing : il se réduit"
        })
        root.addView(footer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            header.setPadding(bars.left + dp(8), bars.top + dp(4), bars.right + dp(8), 0)
            footer.setPadding(bars.left + dp(20), 0, bars.right + dp(20), bars.bottom + dp(20))
            insets
        }
        setContentView(root)

        tracker = HandTracker(
            this,
            onHands = { hands, aspect -> runOnUiThread { showHands(hands, aspect) } },
            onError = { message -> runOnUiThread { say(message) } }
        )

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startTracking()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun say(text: String) {
        status.text = text
    }

    private fun showHands(hands: List<List<PointF>>, aspect: Float) {
        val mode = gestures.update(hands, aspect)
        overlay.update(hands, if (mode == HandMode.NONE) null else gestures.cursor, mode)
        say(
            when (mode) {
                HandMode.NONE -> "Montre ta main à la caméra, paume vers toi."
                HandMode.OPEN -> "Main ouverte"
                HandMode.PINCH -> "Pincement"
                HandMode.FIST -> "Poing"
            }
        )
    }

    private fun startTracking() {
        say("Chargement de la détection de main…")
        executor.execute {
            val ok = tracker.start()
            if (ok) runOnUiThread { bindCamera() }
        }
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { proxy -> tracker.analyze(proxy, true) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
                say("Montre ta main à la caméra, paume vers toi.")
            } catch (e: Exception) {
                say("Impossible de démarrer la caméra : ${e.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        provider?.unbindAll()
        tracker.close()
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        private val BG = Color.parseColor("#0B1220")
        private val TEXT = Color.parseColor("#E6EDF7")
        private val MUTED = Color.parseColor("#8A97AD")
    }
}
