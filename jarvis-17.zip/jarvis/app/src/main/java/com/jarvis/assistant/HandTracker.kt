package com.jarvis.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.PointF
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Détection des mains avec MediaPipe (gratuit, hors ligne).
 * Reçoit les images de la caméra, renvoie pour chaque main les 21 points en coordonnées 0..1.
 * Les résultats arrivent sur un fil de calcul : l'appelant doit repasser sur le fil principal.
 */
class HandTracker(
    context: Context,
    private val onHands: (hands: List<List<PointF>>, aspect: Float) -> Unit,
    private val onError: (message: String) -> Unit
) {
    private val appContext = context.applicationContext
    private var landmarker: HandLandmarker? = null
    private var lastTimestamp = 0L

    @Volatile
    private var aspect = 0.75f

    /** Charge le modèle. À appeler hors du fil principal. Renvoie false si le modèle est absent. */
    fun start(): Boolean {
        return try {
            val base = BaseOptions.builder().setModelAssetPath(MODEL_FILE).build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setResultListener { result, _ -> deliver(result) }
                .setErrorListener { e -> onError(e.message ?: "Erreur de détection de la main.") }
                .build()
            landmarker = HandLandmarker.createFromOptions(appContext, options)
            true
        } catch (e: Exception) {
            onError("Le modèle de la main est introuvable. Recompile l'app avec une connexion Internet.")
            false
        }
    }

    /** Envoie une image de la caméra à la détection. Ferme toujours l'image. */
    fun analyze(proxy: ImageProxy, mirror: Boolean) {
        val lm = landmarker
        if (lm == null) {
            proxy.close()
            return
        }
        try {
            val source = proxy.toBitmap()
            val matrix = Matrix()
            matrix.postRotate(proxy.imageInfo.rotationDegrees.toFloat())
            if (mirror) matrix.postScale(-1f, 1f)
            val upright = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
            aspect = upright.width.toFloat() / upright.height.toFloat()

            var ts = SystemClock.uptimeMillis()
            if (ts <= lastTimestamp) ts = lastTimestamp + 1
            lastTimestamp = ts
            lm.detectAsync(BitmapImageBuilder(upright).build(), ts)
        } catch (e: Exception) {
            onError("Erreur d'analyse de l'image : ${e.message}")
        } finally {
            proxy.close()
        }
    }

    private fun deliver(result: HandLandmarkerResult) {
        val hands = result.landmarks().map { hand -> hand.map { PointF(it.x(), it.y()) } }
        onHands(hands, aspect)
    }

    fun close() {
        try {
            landmarker?.close()
        } catch (e: Exception) {
        }
        landmarker = null
    }

    companion object {
        /** Fichier téléchargé automatiquement dans les assets au moment de la compilation. */
        const val MODEL_FILE = "hand_landmarker.task"
    }
}
