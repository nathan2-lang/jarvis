package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * Ce qui s'ouvre quand tu touches l'icône Nova. Il n'affiche rien et se ferme tout de suite :
 *  - si Nova est prêt, il démarre l'écoute et la barre + la bulle apparaissent par-dessus ton écran
 *    (comme un assistant), sans ouvrir d'application ;
 *  - sinon (clé Gemini, micro ou affichage par-dessus les autres applis manquants), il te le dit
 *    et t'amène là où il faut le régler.
 * Le grand écran de Nova reste accessible par un appui long sur l'icône (« Écran Nova »).
 *
 * Il tourne dans sa propre tâche (taskAffinity vide dans le manifeste) : en se fermant, il ne
 * ramène jamais le grand écran de Nova resté en mémoire.
 */
class LauncherActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var finished = false
    private val stateListener: () -> Unit = {
        if (JarvisState.phase != Phase.STOPPED) done()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (route()) {
            // Android exige que l'appli soit visible au moment où le service micro démarre :
            // on reste invisible jusqu'à ce que Nova ait démarré (2,5 s au maximum).
            if (JarvisState.phase != Phase.STOPPED) {
                handler.postDelayed({ done() }, 400)
            } else {
                JarvisState.addListener(stateListener)
                handler.postDelayed({ done() }, 2500)
            }
        } else {
            done()
        }
    }

    override fun onDestroy() {
        JarvisState.removeListener(stateListener)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun done() {
        if (finished) return
        finished = true
        JarvisState.removeListener(stateListener)
        handler.removeCallbacksAndMessages(null)
        finishAndRemoveTask()
        overridePendingTransition(0, 0)
    }

    /** Vrai si l'écoute a été demandée au service ; faux si on a envoyé l'utilisateur régler quelque chose. */
    private fun route(): Boolean {
        val prefs = getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE)
        val hasKey = prefs.getString(JarvisService.KEY_API, "").orEmpty().isNotBlank()
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

        if (!hasKey) {
            Toast.makeText(this, "Nova : ajoute ta clé Gemini dans les réglages.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            return false
        }
        if (!micOk) {
            Toast.makeText(
                this,
                "Nova : autorise le micro (touche la barre du bas de l'écran Nova).",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(this, MainActivity::class.java))
            return false
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Autorise Nova à s'afficher par-dessus les autres applis, puis touche Nova de nouveau.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).setData(Uri.parse("package:$packageName"))
            )
            return false
        }
        // Démarre Nova s'il est arrêté, et l'écoute tout de suite (comme un assistant).
        ContextCompat.startForegroundService(
            this,
            Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_LISTEN)
        )
        return true
    }
}
