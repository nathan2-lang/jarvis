package com.jarvis.assistant

import android.graphics.PointF
import kotlin.math.hypot

enum class HandMode { NONE, OPEN, PINCH, FIST }

/**
 * Transforme les 21 points d'une main (coordonnées 0..1) en geste :
 * main ouverte, pincement (pouce + index) ou poing.
 * Le pincement a une marge (hystérésis) pour éviter les à-coups.
 */
class HandGestures {

    var pinching = false
        private set

    /** Position du curseur (0..1) : entre le pouce et l'index si on pince, sinon la paume. */
    var cursor = PointF(0.5f, 0.5f)
        private set

    private fun d(a: PointF, b: PointF, aspect: Float): Float =
        hypot((a.x - b.x) * aspect, a.y - b.y)

    /** [aspect] = largeur / hauteur de l'image analysée, pour mesurer les distances sans déformation. */
    fun update(hands: List<List<PointF>>, aspect: Float): HandMode {
        if (hands.isEmpty() || hands[0].size < 21) {
            pinching = false
            return HandMode.NONE
        }
        val h = hands[0]
        val size = maxOf(d(h[0], h[9], aspect), 0.01f)
        val ratio = d(h[4], h[8], aspect) / size
        pinching = if (pinching) ratio < 0.5f else ratio < 0.32f

        var folded = 0
        for (i in 0..3) {
            if (d(h[TIPS[i]], h[0], aspect) < d(h[PIPS[i]], h[0], aspect) * 1.05f) folded++
        }

        cursor = if (pinching) {
            PointF((h[4].x + h[8].x) / 2f, (h[4].y + h[8].y) / 2f)
        } else {
            PointF((h[0].x + h[9].x) / 2f, (h[0].y + h[9].y) / 2f)
        }

        return when {
            pinching -> HandMode.PINCH
            folded >= 3 -> HandMode.FIST
            else -> HandMode.OPEN
        }
    }

    companion object {
        private val TIPS = intArrayOf(8, 12, 16, 20)
        private val PIPS = intArrayOf(6, 10, 14, 18)
    }
}
