plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jarvis.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jarvis.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "3.4"
    }

    // Clé de signature fixe : chaque nouvelle version s'installe par-dessus la précédente,
    // sans désinstaller (et sans perdre la clé Gemini enregistrée).
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storeType = "pkcs12"
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    // Le modèle de la main (.task) est lu tel quel, sans compression
    androidResources {
        noCompress += "task"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Mot de réveil « Nova » : Vosk, gratuit, hors ligne, sans compte
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
    // Main virtuelle : caméra (CameraX) + détection de la main (MediaPipe), gratuit et hors ligne
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Télécharge le modèle de la main au moment de la compilation (une seule fois).
// Si le téléchargement échoue, la compilation continue : l'app affichera un message au lieu de planter.
val handModelFile = layout.projectDirectory.file("src/main/assets/hand_landmarker.task").asFile
val downloadHandModel = tasks.register("downloadHandModel") {
    outputs.file(handModelFile)
    doLast {
        if (!handModelFile.exists() || handModelFile.length() < 1_000_000L) {
            try {
                handModelFile.parentFile.mkdirs()
                val url = java.net.URL("https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task")
                url.openStream().use { input ->
                    handModelFile.outputStream().use { out -> input.copyTo(out) }
                }
            } catch (e: Exception) {
                handModelFile.delete()
                logger.warn("Modele de la main non telecharge : ${e.message}")
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadHandModel) }
