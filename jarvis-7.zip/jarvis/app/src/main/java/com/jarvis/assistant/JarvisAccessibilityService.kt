package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Appuie sur « Envoyer » dans WhatsApp, mais seulement après une commande vocale
 * que tu as confirmée (voir [arm]), et seulement pendant 90 secondes.
 * Le temps que tu déverrouilles ton téléphone avec ton code.
 *
 * À activer une fois dans Réglages > Accessibilité > Jarvis.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Rien à faire si aucun envoi n'a été demandé (ou s'il a expiré).
        if (SystemClock.elapsedRealtime() > armedUntil) return
        val pkg = event?.packageName?.toString() ?: return
        if (pkg != WA && pkg != WA_BUSINESS) return

        val root = rootInActiveWindow ?: return
        val send = findSend(root) ?: return
        if (send.isEnabled && send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            armedUntil = 0L // un seul envoi par commande
        }
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (pkg in listOf(WA, WA_BUSINESS)) {
            val byId = root.findAccessibilityNodeInfosByViewId("$pkg:id/send")
            if (!byId.isNullOrEmpty()) return byId[0]
        }
        return findByDescription(root, 0)
    }

    private fun findByDescription(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 25) return null
        val d = node.contentDescription?.toString()?.trim()?.lowercase()
        if (d == "envoyer" || d == "send") return node
        for (i in 0 until node.childCount) {
            val hit = findByDescription(node.getChild(i), depth + 1)
            if (hit != null) return hit
        }
        return null
    }

    companion object {
        private const val WA = "com.whatsapp"
        private const val WA_BUSINESS = "com.whatsapp.w4b"

        @Volatile
        private var running = false

        @Volatile
        private var armedUntil = 0L

        /** Vrai si l'utilisateur a activé le service dans les réglages d'accessibilité. */
        fun isRunning(): Boolean = running

        /** Autorise l'envoi automatique du prochain message WhatsApp pendant [forMs] millisecondes. */
        fun arm(forMs: Long = 90_000L) {
            armedUntil = SystemClock.elapsedRealtime() + forMs
        }
    }
}
