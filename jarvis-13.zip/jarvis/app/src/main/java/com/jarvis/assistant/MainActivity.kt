package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

/**
 * Écran principal de Kôrô : la bulle lumineuse, la salutation et la barre du bas.
 * Les réglages (clé Gemini, autorisations…) sont dans [SettingsActivity] (roue en haut à droite).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var panel: KoroPanel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Plein écran : la bulle passe derrière l'heure et la barre de gestes.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        panel = KoroPanel(this, isOverlay = false)
        panel.onBarClick = { onBarTapped() }
        panel.onSettings = { startActivity(Intent(this, SettingsActivity::class.java)) }
        setContentView(panel)

        handleStartRequest(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleStartRequest(intent)
    }

    /** Les réglages peuvent demander le démarrage de Kôrô. */
    private fun handleStartRequest(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_START, false) == true) {
            intent?.removeExtra(EXTRA_START)
            start()
        }
    }

    override fun onResume() {
        super.onResume()
        // L'écran principal est visible : la surcouche reste cachée.
        JarvisState.setScreenVisible(true)
        panel.render()
    }

    override fun onPause() {
        JarvisState.setScreenVisible(false)
        super.onPause()
    }

    // ---------- Actions ----------

    private fun onBarTapped() {
        if (JarvisState.phase == Phase.STOPPED) {
            start()
        } else {
            startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_LISTEN))
        }
    }

    private fun start() {
        val prefs = getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE)
        if (prefs.getString(JarvisService.KEY_API, "").orEmpty().isBlank()) {
            Toast.makeText(this, "Renseigne ta clé Gemini dans les réglages.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }

        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        needed.addAll(OPTIONAL_PERMS)
        val missing = needed.filter { !granted(it) }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_START)
            return
        }
        launchService()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != REQ_START) return
        if (granted(Manifest.permission.RECORD_AUDIO)) launchService()
        else Toast.makeText(this, "Le micro est nécessaire.", Toast.LENGTH_LONG).show()
    }

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    /** Le service micro doit être lancé pendant que l'app est visible (règle Android 14+). */
    private fun launchService() {
        ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
        Toast.makeText(this, "Kôrô démarre. Attends « Kôrô est prêt », puis dis « Kôrô ».", Toast.LENGTH_LONG).show()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Pour voir Kôrô par-dessus tes applis, autorise l'affichage par-dessus les autres applis dans les réglages.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    companion object {
        const val EXTRA_START = "start_koro"
        private const val REQ_START = 42

        val OPTIONAL_PERMS = listOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR
        )
    }
}
