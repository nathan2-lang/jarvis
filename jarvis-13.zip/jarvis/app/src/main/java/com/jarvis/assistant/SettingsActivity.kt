package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.pm.PackageManager

/** Réglages de Kôrô : clé Gemini, prénom, mot de réveil, autorisations. */
class SettingsActivity : AppCompatActivity() {

    private lateinit var apiKeyField: EditText
    private lateinit var nameField: EditText
    private lateinit var wakeField: EditText
    private lateinit var startStopButton: Button

    private val density by lazy { resources.displayMetrics.density }
    private fun dp(v: Int): Int = (v * density).toInt()

    private val stateListener: () -> Unit = { renderButton() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE)
        val pad = dp(22)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(12), pad, dp(32))
        }

        // --- En-tête ---
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "←"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        header.addView(TextView(this).apply {
            text = "Réglages"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setTextColor(TEXT)
            setPadding(dp(8), 0, 0, 0)
        })
        root.addView(header)

        // --- Clé Gemini ---
        root.addView(sectionTitle("Clé Gemini"))
        apiKeyField = field("Clé API Gemini (AIza…)", prefs.getString(JarvisService.KEY_API, ""), secret = true)
        root.addView(apiKeyField, matchWrap().apply { topMargin = dp(8) })

        // --- Personnalisation ---
        root.addView(sectionTitle("Personnalisation"))
        nameField = field("Ton prénom (pour la salutation)", prefs.getString(JarvisService.KEY_NAME, ""))
        root.addView(nameField, matchWrap().apply { topMargin = dp(8) })

        root.addView(TextView(this).apply {
            text = "Mot de réveil. Kôrô est écouté par un modèle anglais, qui l'entend comme un mot proche " +
                "(coro, cora…). Si Kôrô ne réagit pas quand tu l'appelles, ajoute ici d'autres mots qu'il " +
                "pourrait entendre, séparés par des virgules. Puis arrête et redémarre Kôrô."
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(MUTED)
            setPadding(0, dp(16), 0, 0)
        })
        wakeField = field(
            "Mots de réveil",
            prefs.getString(JarvisService.KEY_WAKE, JarvisService.DEFAULT_WAKE)
        )
        root.addView(wakeField, matchWrap().apply { topMargin = dp(8) })

        root.addView(SwitchCompat(this).apply {
            text = "Conversation continue : j'écoute la suite sans redire « Kôrô »"
            setTextColor(TEXT)
            isChecked = prefs.getBoolean(JarvisService.KEY_FOLLOWUP, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(JarvisService.KEY_FOLLOWUP, checked).apply()
            }
        }, matchWrap().apply { topMargin = dp(20) })

        // --- Autorisations ---
        root.addView(sectionTitle("Autorisations"))
        root.addView(button("Autoriser l'affichage par-dessus les autres applis") {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Déjà autorisé.", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).setData(Uri.parse("package:$packageName"))
                )
            }
        }, buttonParams(topMargin = dp(8)))
        root.addView(button("Autoriser contacts, appels, SMS et agenda") { askOptionalPermissions() }, buttonParams())
        root.addView(button("Autoriser l'arrière-plan (batterie)") { requestIgnoreBatteryOptimizations() }, buttonParams())
        root.addView(button("Activer l'accessibilité (envoi WhatsApp + ouverture d'applis)") {
            Toast.makeText(this, "Active « Kôrô (WhatsApp et ouverture d'applis) » dans la liste.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, buttonParams())

        // --- Démarrer / arrêter ---
        startStopButton = Button(this).apply {
            isAllCaps = false
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(BG)
            background = GradientDrawable().apply {
                cornerRadius = dp(27).toFloat()
                setColor(CYAN)
            }
            setOnClickListener { onStartStop() }
        }
        root.addView(startStopButton, buttonParams(topMargin = dp(28)))

        // --- Exemples ---
        root.addView(sectionTitle("Ce que tu peux dire"))
        root.addView(TextView(this).apply {
            text = "• « Kôrô » puis :\n" +
                "• ouvre WhatsApp\n" +
                "• appelle Maman\n" +
                "• envoie un SMS à Paul pour dire que j'arrive\n" +
                "• envoie un WhatsApp à Paul pour dire que j'arrive\n" +
                "• joue Burna Boy sur Spotify / coupe la musique\n" +
                "• merci ou ok : j'arrête d'écouter\n" +
                "• allume la lampe / éteins la lampe\n" +
                "• monte le volume / volume à 50\n" +
                "• mets en pause / chanson suivante\n" +
                "• minuteur de 10 minutes / réveille-moi à 7h\n" +
                "• ajoute un rendez-vous demain à 14h à l'agenda\n" +
                "• rappelle-moi demain à 9h d'appeler Paul\n" +
                "• qu'est-ce que j'ai demain à l'agenda ?\n" +
                "• rappelle-moi dans 20 minutes de sortir le riz\n" +
                "• quelle heure est-il ? / combien de batterie ?\n" +
                "• et toute autre question : Gemini répond"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(MUTED)
            setLineSpacing(0f, 1.25f)
            setPadding(0, dp(8), 0, 0)
        })

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(scroll)
        renderButton()
    }

    override fun onResume() {
        super.onResume()
        JarvisState.addListener(stateListener)
        renderButton()
    }

    override fun onPause() {
        JarvisState.removeListener(stateListener)
        save()
        super.onPause()
    }

    private fun save() {
        getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE).edit()
            .putString(JarvisService.KEY_API, apiKeyField.text.toString().trim())
            .putString(JarvisService.KEY_NAME, nameField.text.toString().trim())
            .putString(JarvisService.KEY_WAKE, wakeField.text.toString().trim())
            .apply()
    }

    private fun renderButton() {
        startStopButton.text = if (JarvisState.phase == Phase.STOPPED) "Démarrer Kôrô" else "Arrêter Kôrô"
    }

    private fun onStartStop() {
        save()
        if (JarvisState.phase == Phase.STOPPED) {
            // Le démarrage (micro, service) se fait depuis l'écran principal.
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(MainActivity.EXTRA_START, true)
            )
            finish()
        } else {
            startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
        }
    }

    private fun askOptionalPermissions() {
        val missing = MainActivity.OPTIONAL_PERMS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            Toast.makeText(this, "Déjà autorisé.", Toast.LENGTH_SHORT).show()
            return
        }
        ActivityCompat.requestPermissions(this, missing.toTypedArray(), 43)
    }

    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Déjà autorisé.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:$packageName"))
        )
    }

    // ---------- Petits utilitaires d'affichage ----------

    private fun field(hintText: String, value: String?, secret: Boolean = false) = EditText(this).apply {
        hint = hintText
        inputType = if (secret) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        setText(value.orEmpty())
        setTextColor(TEXT)
        setHintTextColor(MUTED)
        background = GradientDrawable().apply {
            setColor(CARD)
            cornerRadius = dp(14).toFloat()
        }
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun buttonParams(topMargin: Int = dp(12)) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply {
            this.topMargin = topMargin
        }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text.uppercase()
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        letterSpacing = 0.2f
        setTextColor(CYAN)
        setPadding(0, dp(30), 0, 0)
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        setTextColor(CYAN)
        background = GradientDrawable().apply {
            cornerRadius = dp(27).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(2), CYAN)
        }
        setOnClickListener { onClick() }
    }

    companion object {
        private val BG = Color.parseColor("#0B1220")
        private val CARD = Color.parseColor("#141E33")
        private val TEXT = Color.parseColor("#E6EDF7")
        private val MUTED = Color.parseColor("#8A97AD")
        private val CYAN = Color.parseColor("#22D3EE")
    }
}
