package com.jarvis.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * La bulle de Kôrô : une sphère lumineuse dessinée à la main.
 *  - en attente : elle respire doucement ;
 *  - à l'écoute : elle gonfle et ondule avec le volume de ta voix, des ondes partent du centre ;
 *  - en réflexion : le ruban de lumière tourne vite ;
 *  - quand il parle : la bulle se déforme en vagues régulières.
 */
class OrbView(context: Context) : View(context) {

    private var phase = Phase.WAITING
    private var time = 0f
    private var lastNanos = 0L
    private var energy = 0.12f
    private var smoothLevel = 0f
    private var spin = 0f

    private var cx = 0f
    private var cy = 0f
    private var radius = 0f

    private val path = Path()
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ribbonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ribbon2Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    fun setPhase(p: Phase) {
        if (p == phase) return
        phase = p
        rebuildShaders()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cx = w / 2f
        cy = h / 2f
        radius = min(w, h) / 2f * 0.46f
        rebuildShaders()
    }

    private fun tint(): Int = when (phase) {
        Phase.STOPPED -> Color.parseColor("#4B6A9B")
        Phase.LOADING -> Color.parseColor("#6D8FD6")
        Phase.WAITING -> Color.parseColor("#2F7BFF")
        Phase.LISTENING -> Color.parseColor("#2FB4FF")
        Phase.THINKING -> Color.parseColor("#8B7CFF")
        Phase.SPEAKING -> Color.parseColor("#4A8DFF")
    }

    private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun lighten(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt()
    )

    private fun rebuildShaders() {
        if (radius <= 0f) return
        val t = tint()
        val half = min(width, height) / 2f

        // Halo lumineux autour de la bulle (il s'éteint exactement au bord de la vue).
        glowPaint.shader = RadialGradient(
            cx, cy, half,
            intArrayOf(withAlpha(t, 0x80), withAlpha(t, 0x30), withAlpha(t, 0x00)),
            floatArrayOf(0.3f, 0.62f, 1f),
            Shader.TileMode.CLAMP
        )

        // Corps de la sphère : sombre au centre, bleu lumineux vers les bords, comme du verre.
        bodyPaint.shader = RadialGradient(
            cx - radius * 0.2f, cy - radius * 0.25f, radius * 1.35f,
            intArrayOf(Color.parseColor("#06102E"), withAlpha(t, 0xB0), lighten(t, 0.35f)),
            floatArrayOf(0.15f, 0.78f, 1f),
            Shader.TileMode.CLAMP
        )

        // Rubans de lumière qui tournent à l'intérieur.
        val bright = lighten(t, 0.75f)
        ribbonPaint.strokeWidth = radius * 0.55f
        ribbonPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                withAlpha(t, 0x00), withAlpha(t, 0x00), withAlpha(t, 0xC0), bright, withAlpha(t, 0x00)
            ),
            floatArrayOf(0f, 0.35f, 0.65f, 0.82f, 1f)
        )
        ribbon2Paint.strokeWidth = radius * 0.4f
        ribbon2Paint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                withAlpha(lighten(t, 0.3f), 0x00), withAlpha(lighten(t, 0.3f), 0x00),
                withAlpha(lighten(t, 0.5f), 0x90), withAlpha(Color.WHITE, 0xD0), withAlpha(t, 0x00)
            ),
            floatArrayOf(0f, 0.5f, 0.75f, 0.9f, 1f)
        )

        rimPaint.strokeWidth = radius * 0.035f
        rimPaint.color = withAlpha(lighten(t, 0.7f), 0xB0)
        ripplePaint.strokeWidth = radius * 0.03f
        ripplePaint.color = lighten(t, 0.5f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastNanos = 0L
        postInvalidateOnAnimation()
    }

    /** Avance l'animation selon le temps réellement écoulé. */
    private fun step() {
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0.016f else ((now - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastNanos = now
        time += dt

        smoothLevel += (JarvisState.level - smoothLevel) * min(1f, dt * 12f)

        val target = when (phase) {
            Phase.STOPPED -> 0.05f
            Phase.LOADING -> 0.18f
            Phase.WAITING -> 0.14f
            Phase.LISTENING -> 0.25f + smoothLevel * 0.75f
            Phase.THINKING -> 0.4f
            Phase.SPEAKING -> 0.85f
        }
        energy += (target - energy) * min(1f, dt * 6f)

        val spinSpeed = when (phase) {
            Phase.STOPPED -> 6f
            Phase.LOADING -> 50f
            Phase.WAITING -> 14f
            Phase.LISTENING -> 28f
            Phase.THINKING -> 170f
            Phase.SPEAKING -> 55f
        }
        spin = (spin + spinSpeed * dt) % 360f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (radius <= 0f) return
        step()

        val speed = when (phase) {
            Phase.SPEAKING -> 2.4f
            Phase.LISTENING -> 1.4f
            Phase.THINKING -> 1.8f
            else -> 0.6f
        }
        val t1 = time * 1.7f * speed
        val t2 = time * 2.3f * speed
        val t3 = time * 3.1f * speed

        // Taille globale : respiration, gonflement avec la voix, pulsation quand il parle.
        val scale = when (phase) {
            Phase.LISTENING -> 1f + 0.03f * sin(time * 1.6f) + 0.14f * smoothLevel
            Phase.SPEAKING -> 1f + 0.045f * sin(time * 6.5f) + 0.02f * sin(time * 2.7f)
            Phase.THINKING -> 0.97f + 0.02f * sin(time * 3f)
            else -> 1f + 0.035f * sin(time * 1.6f)
        }
        val r = radius * scale

        // Halo
        glowPaint.alpha = (255 * (0.55f + 0.45f * energy)).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, min(width, height) / 2f, glowPaint)

        // Ondes qui partent du centre quand il écoute.
        if (phase == Phase.LISTENING) {
            for (i in 0..1) {
                val p = (time * 0.7f + i * 0.5f) % 1f
                ripplePaint.alpha = ((1f - p) * (40f + 150f * smoothLevel)).toInt().coerceIn(0, 255)
                canvas.drawCircle(cx, cy, r * (1.05f + 0.5f * p), ripplePaint)
            }
        }

        // Contour ondulant de la bulle.
        val n = 72
        path.rewind()
        for (i in 0..n) {
            val a = (i % n) * 2f * PI.toFloat() / n
            val wob = 1f + energy * (
                0.06f * sin(2f * a + t1) +
                    0.05f * sin(3f * a - t2) +
                    0.035f * sin(5f * a + t3)
                )
            val x = cx + cos(a) * r * wob
            val y = cy + sin(a) * r * wob
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()

        canvas.drawPath(path, bodyPaint)

        // Rubans de lumière, découpés dans la bulle.
        canvas.save()
        canvas.clipPath(path)
        canvas.save()
        canvas.rotate(spin, cx, cy)
        canvas.drawCircle(cx, cy, r * 0.72f, ribbonPaint)
        canvas.restore()
        canvas.save()
        canvas.rotate(-spin * 1.35f + 70f, cx, cy)
        canvas.drawCircle(cx, cy, r * 0.5f, ribbon2Paint)
        canvas.restore()
        canvas.restore()

        canvas.drawPath(path, rimPaint)

        postInvalidateOnAnimation()
    }
}
