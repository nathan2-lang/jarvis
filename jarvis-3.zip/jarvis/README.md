# Jarvis pour Android

Assistant vocal : tu appuies sur « Parler » dans la notification, tu poses ta question, et Gemini te répond à voix haute. Fonctionne écran verrouillé.

## Ce qu'il te faut

Une **clé API Gemini gratuite** : https://aistudio.google.com/apikey (compte Google requis).

## Utilisation

1. Ouvre l'app, colle ta clé Gemini, appuie sur **Démarrer Jarvis** et accepte les permissions (micro, notifications).
2. Appuie sur **Autoriser l'arrière-plan (batterie)**.
3. Une notification « Jarvis » apparaît. Appuie sur **Parler**, attends le bip, pose ta question.

## Notes

- **Android 14+** : le service micro doit être démarré quand l'app est visible, d'où le bouton *Démarrer Jarvis*.
- Le modèle utilisé est défini dans `GeminiClient.kt` (`MODEL`).
- L'offre gratuite a des limites de requêtes par minute et par jour.
