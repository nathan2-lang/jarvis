package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var apiKeyField: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Jarvis"
            textSize = 32f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Appuie sur « Parler » dans la notification, même écran verrouillé."
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
        })

        apiKeyField = EditText(this).apply {
            hint = "Clé API Gemini (AIza…)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString(JarvisService.KEY_API, ""))
        }
        root.addView(apiKeyField)

        root.addView(Button(this).apply {
            text = "Démarrer Jarvis"
            setOnClickListener { start() }
        })
        root.addView(Button(this).apply {
            text = "Arrêter Jarvis"
            setOnClickListener {
                startService(Intent(this@MainActivity, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
            }
        })
        root.addView(Button(this).apply {
            text = "Autoriser l'arrière-plan (batterie)"
            setOnClickListener { requestIgnoreBatteryOptimizations() }
        })

        setContentView(root)
    }

    private fun start() {
        val c = apiKeyField.text.toString().trim()
        if (c.isEmpty()) {
            Toast.makeText(this, "Renseigne ta clé Gemini.", Toast.LENGTH_SHORT).show()
            return
        }
        getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE).edit()
            .putString(JarvisService.KEY_API, c)
            .apply()

        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMS)
            return
        }
        launchService()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != REQ_PERMS) return
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (micOk) launchService()
        else Toast.makeText(this, "Le micro est nécessaire.", Toast.LENGTH_LONG).show()
    }

    /** Le service micro doit être lancé pendant que l'app est visible (règle Android 14+). */
    private fun launchService() {
        ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
        Toast.makeText(this, "Jarvis est prêt. Utilise « Parler » dans la notification.", Toast.LENGTH_LONG).show()
    }

    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Déjà autorisé.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:$packageName"))
        )
    }

    companion object {
        private const val REQ_PERMS = 42
    }
}
