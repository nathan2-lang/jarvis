package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Service au premier plan. Un appui sur « Parler » dans la notification
 * lance l'écoute ; la question part vers Gemini et la réponse est lue à voix haute.
 */
class JarvisService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var gemini: GeminiClient? = null

    /** Évite de lancer deux écoutes en même temps. */
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val apiKey = prefs.getString(KEY_API, "").orEmpty()
        if (apiKey.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (gemini == null) gemini = GeminiClient(apiKey)
        if (tts == null) initTts()

        if (intent?.action == ACTION_LISTEN) startListening()

        return START_STICKY
    }

    // ---------- Notification (obligatoire pour un service au premier plan) ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val listen = serviceIntent(ACTION_LISTEN, 1)
        val stop = serviceIntent(ACTION_STOP, 2)

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis")
            .setContentText("Appuie sur « Parler » pour poser ta question")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(listen)
            .addAction(0, "Parler", listen)
            .addAction(0, "Arrêter", stop)
            .build()
        startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun serviceIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(
            this, requestCode,
            Intent(this, JarvisService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE
        )

    // ---------- Reconnaissance vocale ----------

    private fun startListening() {
        if (busy) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("La reconnaissance vocale n'est pas disponible sur ce téléphone.")
            return
        }
        busy = true

        // Petit bip pour signaler que Jarvis écoute.
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        } catch (_: Exception) {}

        main.postDelayed({ beginRecognition() }, 300)
    }

    private fun beginRecognition() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) {
                    busy = false
                } else {
                    askGemini(text)
                }
            }

            override fun onError(error: Int) {
                busy = false
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
        )
    }

    // ---------- Gemini ----------

    private fun askGemini(question: String) {
        scope.launch {
            val reply = withContext(Dispatchers.IO) { gemini?.ask(question) ?: "Jarvis n'est pas prêt." }
            busy = false
            speak(reply)
        }
    }

    // ---------- Synthèse vocale ----------

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.FRENCH
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    // ---------- Arrêt ----------

    override fun onDestroy() {
        scope.cancel()
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val PREFS = "jarvis"
        const val KEY_API = "gemini_key"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        const val ACTION_LISTEN = "com.jarvis.assistant.LISTEN"
        private const val CHANNEL_ID = "jarvis_channel"
        private const val NOTIF_ID = 1
    }
}
