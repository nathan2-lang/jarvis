package com.jarvis.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Client minimal pour l'API Gemini (offre gratuite de Google AI Studio). */
class GeminiClient(private val apiKey: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    /** Historique : paires (rôle, texte), rôle = "user" ou "model". */
    private val history = mutableListOf<Pair<String, String>>()

    /** Envoie une phrase et retourne la réponse (appel bloquant : à lancer hors du thread principal). */
    fun ask(userText: String): String {
        history.add("user" to userText)

        val contents = JSONArray()
        history.forEach { (role, text) ->
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }

        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT)))
            )
            .put("contents", contents)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body)
            .build()

        return try {
            http.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    history.removeLastOrNull()
                    return when (response.code) {
                        429 -> "Limite gratuite atteinte. Réessaie dans une minute."
                        400, 403 -> "Ta clé Gemini semble invalide."
                        else -> "Erreur ${response.code} de l'API Gemini."
                    }
                }
                val candidates = JSONObject(raw).optJSONArray("candidates")
                val parts = candidates
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                val reply = buildString {
                    if (parts != null) {
                        for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
                    }
                }.trim()

                if (reply.isEmpty()) {
                    history.removeLastOrNull()
                    return "Je ne peux pas répondre à ça."
                }
                history.add("model" to reply)
                trimHistory()
                reply
            }
        } catch (e: Exception) {
            history.removeLastOrNull()
            "Je n'arrive pas à joindre Gemini. Vérifie ta connexion."
        }
    }

    /** Garde les 10 derniers échanges, en commençant toujours par un message utilisateur. */
    private fun trimHistory() {
        while (history.size > 20) history.removeAt(0)
        while (history.isNotEmpty() && history.first().first != "user") history.removeAt(0)
    }

    companion object {
        const val MODEL = "gemini-3.5-flash-lite"

        private const val SYSTEM_PROMPT =
            "Tu es Jarvis, un assistant vocal personnel sur le téléphone Android de l'utilisateur. " +
            "Tu réponds toujours en français. Tes réponses sont lues à voix haute : " +
            "sois bref (une à trois phrases), naturel, sans markdown, sans listes, sans emojis."
    }
}
