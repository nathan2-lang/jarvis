# Jarvis pour Android

Assistant vocal : tu appuies sur « Parler » dans la notification, tu poses ta question, et Claude te répond à voix haute. Fonctionne écran verrouillé.

## Ce qu'il te faut

Une **clé API Claude** : https://console.anthropic.com

## Utilisation

1. Ouvre l'app, colle ta clé Claude, appuie sur **Démarrer Jarvis** et accepte les permissions (micro, notifications).
2. Appuie sur **Autoriser l'arrière-plan (batterie)**.
3. Une notification « Jarvis » apparaît. Appuie sur **Parler**, attends le bip, pose ta question.

## Notes

- **Android 14+** : le service micro doit être démarré quand l'app est visible, d'où le bouton *Démarrer Jarvis*.
- Le modèle utilisé est défini dans `ClaudeClient.kt` (`MODEL`).

## Prochaines étapes

Mot de réveil « Jarvis » (sans compte), ouvrir des apps, alarmes, appels, SMS, voix plus naturelle.
