package com.jarvis.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Client minimal pour l'API Messages de Claude. */
class ClaudeClient(private val apiKey: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    /** Historique : liste de paires (rôle, texte), rôle = "user" ou "assistant". */
    private val history = mutableListOf<Pair<String, String>>()

    /** Envoie une phrase et retourne la réponse de Claude (appel bloquant : à lancer hors du thread principal). */
    fun ask(userText: String): String {
        history.add("user" to userText)

        val messages = JSONArray()
        history.forEach { (role, text) ->
            messages.put(JSONObject().put("role", role).put("content", text))
        }

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 400)
            .put("system", SYSTEM_PROMPT)
            .put("messages", messages)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body)
            .build()

        return try {
            http.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    history.removeLastOrNull()
                    return "Erreur ${response.code} de l'API Claude."
                }
                val reply = JSONObject(raw)
                    .getJSONArray("content")
                    .getJSONObject(0)
                    .getString("text")
                    .trim()
                history.add("assistant" to reply)
                trimHistory()
                reply
            }
        } catch (e: Exception) {
            history.removeLastOrNull()
            "Je n'arrive pas à joindre Claude. Vérifie ta connexion."
        }
    }

    /** Garde les 10 derniers échanges, en commençant toujours par un message utilisateur. */
    private fun trimHistory() {
        while (history.size > 20) history.removeAt(0)
        while (history.isNotEmpty() && history.first().first != "user") history.removeAt(0)
    }

    companion object {
        const val MODEL = "claude-haiku-5-5"

        private const val SYSTEM_PROMPT =
            "Tu es Jarvis, un assistant vocal personnel sur le téléphone Android de l'utilisateur. " +
            "Tu réponds toujours en français. Tes réponses sont lues à voix haute : " +
            "sois bref (une à trois phrases), naturel, sans markdown, sans listes, sans emojis."
    }
}
